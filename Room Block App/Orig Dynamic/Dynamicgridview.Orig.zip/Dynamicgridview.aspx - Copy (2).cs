﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;

using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

using System.Collections.Generic;
using System.Text;
using System.Net;
using log4net;
using Microsoft.Xrm.Client.Services;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Data.Services.Common;
using Xrm; //XrmEarlyBinding;	
//using System.Linq;

// TestData
// Dynamicgridview.aspx?username=TestUser&recordid=%7B19D3942D-2D8D-E311-9D78-534E57000000%7D			35th Infantry Test 2 Roomblocks   ;Roomblock of 3-5 Feb 2014
//49D728F7-BC8D-E211-8F60-534E57000000
//1D036A11-D88C-E311-9D78-534E57000000 35th Infantry Test1
//B2B60147-238F-E311-B8EF-534E57000000   // 7-Eleven: Test 3 Roomblocks - 2015   // Roomblocks 1-7 July 2015

// 1105 MEDIA, Inc: TEst REad Only - 2015
// 4CA85EE6-0793-E311-ACA7-534E57000000

// (Cloned) Test 2 - 
//		Missing Last DAy
// Dynamicgridview.aspx?username=TestUser&recordid=%7BEF57D39E-96F7-E311-AF0B-534E57000000%7D

//http://10.0.0.3:8082/RoomBlocks/Dynamicgridview.aspx?username=TestUser&recordid=%7B19D3942D-2D8D-E311-9D78-534E57000000%7D

namespace RoomBlock
{
    public partial class Dynamicgridview : System.Web.UI.Page
	{
#region "Variable Declaration"

		private static ILog logger = LogManager.GetLogger(typeof(Dynamicgridview));

		private static bool bSHOW_ROOM_GUID = false;
		static OrganizationService _service;

#endregion //"Variable Declaration"

		private DataTable dtretrieve
		{
			get
			{
				return (this.ViewState["dtretrieve"] != null ? 
					(DataTable)this.ViewState["dtretrieve"] : 
					new DataTable());
			}
			set
			{
				this.ViewState["dtretrieve"] = value;
			}
		}

		private DataTable dtRoomBlock
		{
			get
			{
				return (this.ViewState["dtRoomBlock"] != null ? 
					(DataTable)this.ViewState["dtRoomBlock"] : 
					new DataTable());
			}
			set
			{
				this.ViewState["dtRoomBlock"] = value;
			}
		}

		private string getEventStatus
		{
			get
			{
				return (this.ViewState["getEventStatus"] != null
					? (string)this.ViewState["getEventStatus"]
					: string.Empty);
			}
			set
			{
				this.ViewState["getEventStatus"] = value;
			}
		}

		private string Username
		{
			get { return (string)this.ViewState["username"]; }
			set { this.ViewState["username"] = value; }
		}

		public void Build_RoomBlock_Datatable()
		{
			try
			{
				if (HttpContext.Current.Request.QueryString["recordid"] == null)
					return;

				string eventid = Request.QueryString["recordid"].ToString();

				// Get the dates from the event.
				var cols = new ColumnSet(new String[] { 
					"new_arrivaldate", 
					"new_departuredate" });
				var evt = (Opportunity)_service.Retrieve(
					"opportunity", new Guid(eventid), cols);

				DateTime arrivalDate = evt.New_arrivaldate ?? DateTime.MinValue;
				DateTime departureDate = evt.New_departuredate ?? DateTime.MinValue;

				// ensure whole days
				arrivalDate = new DateTime(arrivalDate.Year, arrivalDate.Month, arrivalDate.Day);
				departureDate = new DateTime(departureDate.Year, departureDate.Month, departureDate.Day);

				eventid = eventid.Replace("{", "").Replace("}", "");

				DataTable dt = new DataTable();
				dt.Columns.Add("DayNumber");
				dt.Columns.Add("DayofWeek");
				dt.Columns.Add("Date");
				dt.Columns.Add("Original % of Peak");
				dt.Columns.Add("Original Room Block");
				dt.Columns.Add("Current % of Peak");
				dt.Columns.Add("CurrentRoom Block");
				dt.Columns.Add("GUIDID");
				dt.Columns.Add("RoomGUID");

				/* Test code
				XrmServiceContext context = new XrmServiceContext(_service);
				var x = //context.
				OpportunitySet
				.Where(w => w.OpportunityId.Value == new System.Guid("EF57D39E-96F7-E311-AF0B-534E57000000"))
				.Select(s => new { s.New_arrivaldate, s.New_departuredate })
				.Dump()
				.ToList()
				;
				
				foreach(var v in x)
				{
					String.Format("{0}-{1}",
						v.New_arrivaldate.Value,
						v.New_departuredate.Value)
						.Dump("query result");
						
					DateTime a = new DateTime(v.New_arrivaldate.Value.Year, v.New_arrivaldate.Value.Month, v.New_arrivaldate.Value.Day).Dump("a");
					DateTime d = new DateTime(v.New_departuredate.Value.Year, v.New_departuredate.Value.Month, v.New_departuredate.Value.Day).Dump("a");
					//TimeSpan t = d.Subtract(a).TotalDays;
					
					TimeSpan dtTime = v.New_departuredate.Value.Subtract(v.New_arrivaldate.Value);
					dtTime.Dump("orig span");
					int count = (int)Math.Floor(dtTime.TotalDays);
					String.Format("{0}-{1}-{2}",
						count,
						Math.Floor(dtTime.TotalDays),
						d.Subtract(a).TotalDays,
						)
						//.Dump("orig orig new")
						;
				}*/	

				for (int i = 0; i < departureDate.Subtract(arrivalDate).TotalDays; i++)
				{
					DataRow dr = dt.NewRow();
					dr["DayNumber"] = (i + 1).ToString();
					dr["DayofWeek"] = arrivalDate.AddDays(i).DayOfWeek.ToString();
					dr["Date"] = arrivalDate.AddDays(i).ToShortDateString();
					dr["GUIDID"] = eventid;
					dt.Rows.Add(dr);
				}

				dtRoomBlock = dt;
			}
			catch (Exception ex)
			{
				logger.Error("Build_RoomBlock_Datatable " + ex.ToString());
			}
		}

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                bool rpStatusFlag = false;
                string eventid = string.Empty;
                try
                {
					log4net.Config.XmlConfigurator.Configure();

					_service = CrmServiceManager.GetCrmService();

					this.Username = Request.QueryString["username"].ToString();

                    if (HttpContext.Current.Request.QueryString["status"] == null)
                    {
                        if (HttpContext.Current.Request.QueryString["recordid"] != null)
                        {
                            eventid = Request.QueryString["recordid"].ToString();
                            ViewState["_eventID"] = eventid;
							logger.Info("Page_Load: evenit= " + eventid);

							// Save eventid on page
							((HiddenField)form1.FindControl("hdnfdEventID")).Value = eventid;

                            if (HttpContext.Current.Request.QueryString["rpStatus"] != null)
                            {
                                rpStatusFlag = true;
                                CheckEventUpdateStatus(_service, eventid);
                            }
                            else
                                rpStatusFlag = false;

                            getEventStatus = "";
                            getEventStatus = CheckEventStatus(_service, eventid);
							logger.Info("20 Page_Load: EventStatus000= " + getEventStatus);

							if (getEventStatus != string.Empty && getEventStatus == "10")
							{
								RetrieveBasedonStatus(_service);
								btnsave.Text = "Update";
								btnlead.Enabled = true;
							}
							else
							{
								logger.Info("Debug001: pageload1");
								Retrieve(_service, rpStatusFlag, 0);
							}
                        }
                        else
                        {
                            btnsave.Visible = false;
                            btnlead.Visible = false;
                        }
                    }
                    else
                    {
						logger.Info("Debug001: pageload2");
                        Retrieve(_service, true, 1);
                        btnsave.Text = "Save";
                        btnlead.Enabled = false;
                    }
                }
				catch (System.Web.Services.Protocols.SoapException ex)
				{
					logger.Error(ex.Detail.InnerText, ex);
				}
                catch (Exception ex)
                {
					logger.Error("Page_Load", ex);
                }
                finally //ytodo why is this in finally!!?
                {
                    string _eventID = Convert.ToString(ViewState["_eventID"]);
                    if (_eventID != null && _eventID != string.Empty)
                    {
                        EntityCollection entityCollection = 
							CheckRoomPatternecords(_eventID, _service);

						if (entityCollection.Entities.Count > 0 && ViewState["DisplayDateisNULL"] == null)
                        {
                            btnsave.Text = "Update";
                            btnlead.Enabled = true;
                        }
                        else if (ViewState["DisplayDateisNULL"] != null)
                        {
                            btnsave.Enabled = false;
                            btnlead.Enabled = false;
                        }
                        else
                        {
                            btnsave.Text = "Save";
                            btnlead.Enabled = false;
                            UpdatePeakRoomNights(_eventID);
                        }
                    }
                }
            }
        }

#region Events
        private void UpdatePeakRoomNights(string _eventID)
        {
            try
            {
				//logger.Info("70 Dynamicgridview Page: UpdatePeakRoomNights : Started");
				logger.Info("70 Dynamicgridview Page:  UpdatePeakRoomNights Method: Before service execution");

                Entity entity = new Entity("new_roompattern");
                EntityCollection entityCollection = CheckRoomPatternecords(_eventID, _service);

                //logger.Info("Dynamicgridview Page:  UpdatePeakRoomNights Method: After service execution");
                logger.Info("80 Dynamicgridview Page: entityCollection.BusinessEntities.Length:: " + entityCollection.Entities.Count);

                if (entityCollection.Entities.Count == 0)
                {
                    Entity oppEvent = new Entity("opportunity");
                    oppEvent["new_hotelroomnights"] = 0;
                    oppEvent["new_peakhotelroomnights"] = 0;
                    oppEvent["opportunityid"] = new Guid(_eventID);
                    _service.Update(oppEvent);
                }
				logger.Info("90 Dynamicgridview Page: UpdatePeakRoomNights : Ended NS00: " + _eventID);
            }
			catch (System.Web.Services.Protocols.SoapException ex)
			{
				logger.Error(ex.Detail.InnerText, ex);
			}
            catch (Exception ex)
            {
				logger.Error("Dynamicgridview Page: UpdatePeakRoomNights()", ex);
            }
        }

        protected void btnlead_Click(object sender, EventArgs e)
        {
			//if (!ValidateProposedDates())
			//	return;
            SendLeadtoHotel();
        }

        private void SendLeadtoHotel()
        {
            try
            {
                string _eventID = Convert.ToString(ViewState["_eventID"]);

                if (gvFormLoad.Rows.Count > 0)
                {
                    if (getEventStatus != "10")
                        UpdateRoomblock(_eventID,0);
                    else
                        UpdateRoomblockStatus(_eventID,0);

                    foreach (GridViewRow Item in gvFormLoad.Rows)
                    {
                        TextBox txtcurrent = (TextBox)Item.FindControl("txtCBlock");
                        string currentroom = txtcurrent.Text;

						System.Web.UI.WebControls.
                        Label txtoriginal = (System.Web.UI.WebControls.Label)Item.FindControl("lblOblock");
                        txtoriginal.Text = currentroom;

                        HiddenField txt1 = (HiddenField)Item.FindControl("hdnfdValue");
                        string current = txt1.Value;
						System.Web.UI.WebControls.
                        Label txt2 = (System.Web.UI.WebControls.Label)Item.FindControl("lblOPeak");
                        txt2.Text = current;
                    }

                    for (int i = 0; i < gvFormLoad.Rows.Count; i++)
                    {
                        // Create the contact object.
                        Entity roompattern = new Entity("new_roompattern");
						string RoomGUID = //gvRoomBlock.Rows[i].Cells[7].Text;
								dtretrieve.Rows[i]["RoomGUID"].ToString();
						roompattern["new_roompatternid"] = new Guid(RoomGUID);

						System.Web.UI.WebControls.
                        Label txtOriginalpeak = (System.Web.UI.WebControls.Label)gvFormLoad.Rows[i].FindControl("lblOPeak");
                        string OriginalPeak = txtOriginalpeak.Text;
                        int intOPeak = 0;

                        if ((((System.Web.UI.WebControls.Label)
								(gvFormLoad.Rows[i].FindControl("lblOPeak"))).Text != string.Empty) 
							&& ((System.Web.UI.WebControls.Label)
								(gvFormLoad.Rows[i].FindControl("lblOPeak"))).Text != null)
                        {
                            if (OriginalPeak.Contains("."))
                            {
                                intOPeak = Convert.ToInt32(OriginalPeak.Split('.')[0].ToString());
                            }
                            else
                            {
                                intOPeak = Convert.ToInt32(OriginalPeak);
                            }
                        }
                        else
                        {
                            intOPeak = 0;
                        }
                        roompattern["bcmc_originalpercentofpeak"] = intOPeak;

                        HiddenField txtCurrentpeak = (HiddenField)gvFormLoad.Rows[i].FindControl("hdnfdValue");
                        string CurrentPeak = txtCurrentpeak.Value;
                        int intCPeak = 0;

                        if ((((HiddenField)(gvFormLoad.Rows[i].FindControl("hdnfdValue"))).Value != string.Empty) 
							&& ((HiddenField)(gvFormLoad.Rows[i].FindControl("hdnfdValue"))) != null)
                        {
                            if (CurrentPeak.Contains("."))
                                intCPeak = Convert.ToInt32(CurrentPeak.Split('.')[0].ToString());
                            else
                                intCPeak = Convert.ToInt32(CurrentPeak);
                        }
                        else
                            intCPeak = 0;

                        roompattern["new_percentofpeak"] = intCPeak;

						System.Web.UI.WebControls.
                        Label txtOriginalblock = (System.Web.UI.WebControls.Label)
							gvFormLoad.Rows[i].FindControl("lblOblock");
                        string Originalblock = txtOriginalblock.Text;
                        int intOBlock = 0;

                        if ((((System.Web.UI.WebControls.Label)
								(gvFormLoad.Rows[i].FindControl("lblOblock"))).Text != string.Empty) 
							&& ((System.Web.UI.WebControls.Label)
								(gvFormLoad.Rows[i].FindControl("lblOblock"))).Text != null)
                        {
                            if (Originalblock.Contains("."))
                            {
                                intOBlock = Convert.ToInt32(Originalblock.Split('.')[0].ToString());
                            }
                            else
                            {
                                intOBlock = Convert.ToInt32(Originalblock);
                            }
                        }
                        else
                        {
                            intOBlock = 0;
                        }
                        roompattern["bcmc_originalroomblock"] = intOBlock;

                        TextBox txtcurrentblock = (TextBox)gvFormLoad.Rows[i].FindControl("txtCBlock");
                        string Currentblock = txtcurrentblock.Text;
                        int intCBlock = 0;
                        if ((((TextBox)(gvFormLoad.Rows[i].FindControl("txtCBlock"))).Text != string.Empty) 
							&& ((TextBox)(gvFormLoad.Rows[i].FindControl("txtCBlock"))).Text != null)
                        {
                            if (Currentblock.Contains("."))
                                intCBlock = Convert.ToInt32(Currentblock.Split('.')[0].ToString());
                            else
                                intCBlock = Convert.ToInt32(Currentblock);
                        }
                        else
                            intCBlock = 0;
                        roompattern["new_roomblock"] = intCBlock;

						roompattern["bcmc_user"] = this.Username;
                        _service.Update(roompattern);
                    }

                    string myscript = "alert('Successfully completed.');";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "myscript", myscript, true);
                    btnlead.Enabled = true;
                }
                else if (gvRoomBlock.Rows.Count > 0)
                {
                    if (getEventStatus != "10")
                        UpdateRoomblock(_eventID,0);
                    else
                        UpdateRoomblockStatus(_eventID,0);

                    foreach (GridViewRow Item in gvRoomBlock.Rows)
                    {
                        TextBox txtcurrent = (TextBox)Item.FindControl("txtCBlock");
                        string currentroom = txtcurrent.Text;

						System.Web.UI.WebControls.
                        Label txtoriginal = (System.Web.UI.WebControls.Label)Item.FindControl("lblOblock");
                        txtoriginal.Text = currentroom;

                        HiddenField txt1 = (HiddenField)Item.FindControl("hdnfdValue");
                        string current = txt1.Value;
						System.Web.UI.WebControls.
                        Label txt2 = (System.Web.UI.WebControls.Label)Item.FindControl("lblOPeak");
                        txt2.Text = current;
                    }


                    for (int i = 0; i < gvRoomBlock.Rows.Count; i++)
                    {
                        // Create the contact object.
                        Entity roompattern = new Entity("new_roompattern");
						string RoomGUID = //gvRoomBlock.Rows[i].Cells[8].Text;
								 dtretrieve.Rows[i]["RoomGUID"].ToString();
						Guid current_roompatternid = new Guid(RoomGUID);
						roompattern["new_roompatternid"] = current_roompatternid;

						System.Web.UI.WebControls.
							Label txtOriginalpeak = (System.Web.UI.WebControls.Label)gvRoomBlock.Rows[i].FindControl("lblOPeak");
                        string OriginalPeak = txtOriginalpeak.Text;
                        int intOPeak = Convert.ToInt32(OriginalPeak);
                        if ((((System.Web.UI.WebControls.Label)
							(gvRoomBlock.Rows[i].FindControl("lblOPeak"))).Text != string.Empty) 
							&& ((System.Web.UI.WebControls.Label)
							(gvRoomBlock.Rows[i].FindControl("lblOPeak"))).Text != null)
                        {
                            if (OriginalPeak.Contains("."))
                            {
                                intOPeak = Convert.ToInt32(OriginalPeak.Split('.')[0].ToString());
                            }
                            else
                            {
                                intOPeak = Convert.ToInt32(OriginalPeak);
                            }
                        }
                        else
                        {
                            intOPeak = 0;
                        }
                        roompattern["bcmc_originalpercentofpeak"] = intOPeak;

                        HiddenField txtCurrentpeak = (HiddenField)gvRoomBlock.Rows[i].FindControl("hdnfdValue");
                        string CurrentPeak = txtCurrentpeak.Value;
                        int intCPeak = 0;
                        if ((((HiddenField)(gvRoomBlock.Rows[i].FindControl("hdnfdValue"))).Value != string.Empty) 
							&& ((HiddenField)(gvRoomBlock.Rows[i].FindControl("hdnfdValue"))) != null)
                        {
                            if (CurrentPeak.Contains("."))
                            {
                                intCPeak = Convert.ToInt32(CurrentPeak.Split('.')[0].ToString());
                            }
                            else
                            {
                                intCPeak = Convert.ToInt32(CurrentPeak);
                            }
                        }
                        else
                        {
                            intCPeak = 0;
                        }
                        roompattern["new_percentofpeak"] = intCPeak;

						System.Web.UI.WebControls.
                        Label txtOriginalblock = (System.Web.UI.WebControls.Label)gvRoomBlock.Rows[i].FindControl("lblOblock");
                        string Originalblock = txtOriginalblock.Text;
                        int intOBlock = 0;
                        if ((((System.Web.UI.WebControls.Label)(gvRoomBlock.Rows[i].FindControl("lblOblock"))).Text != string.Empty) 
							&& ((System.Web.UI.WebControls.Label)(gvRoomBlock.Rows[i].FindControl("lblOblock"))).Text != null)
                        {
                            if (Originalblock.Contains("."))
                            {
                                intOBlock = Convert.ToInt32(Originalblock.Split('.')[0].ToString());
                            }
                            else
                            {
                                intOBlock = Convert.ToInt32(Originalblock);
                            }
                        }
                        else
                            intOBlock = 0;
                        roompattern["bcmc_originalroomblock"] = intOBlock;

                        TextBox txtcurrentblock = (TextBox)gvRoomBlock.Rows[i].FindControl("txtCBlock");
                        string Currentblock = txtcurrentblock.Text;
                        int intCBlock = 0;
                        if ((((TextBox)(gvRoomBlock.Rows[i].FindControl("txtCBlock"))).Text != string.Empty) && ((TextBox)(gvRoomBlock.Rows[i].FindControl("txtCBlock"))).Text != null)
                        {
                            if (Currentblock.Contains("."))
                            {
                                intCBlock = Convert.ToInt32(Currentblock.Split('.')[0].ToString());
                            }
                            else
                            {
                                intCBlock = Convert.ToInt32(Currentblock);
                            }
                        }
                        else
                        {
                            intCBlock = 0;
                        }
                        roompattern["new_roomblock"] = intCBlock;

						logger.Info(String.Format("150 Update new_roompatternid {0}=={1}; Roomblock={2}", 
							current_roompatternid,
							gvRoomBlock.Rows[i].Cells[8].Text,
							intCBlock));

						roompattern["bcmc_user"] = this.Username;
                        _service.Update(roompattern);
                    }
                    string myscript = "alert('Successfully completed. ');";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "myscript", myscript, true);
                    btnlead.Enabled = false;

                }
            }
			catch (System.Web.Services.Protocols.SoapException ex)
			{
				logger.Error(ex.Detail.InnerText, ex);
			}
            catch (Exception ex)
            {
				logger.Error("SendLeadtoHotel()", ex);
            }
        }

        protected void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                string _eventID = Convert.ToString(ViewState["_eventID"]);
				//string eventId = ((HiddenField)form1.FindControl("hdnfdEventID")).Value;

				logger.InfoFormat("180 btnsave_Click: eventID1={0}",
					_eventID);
                if (btnsave.Text == "Save")
                {
                    BindSave(_eventID);
                }
                else if (btnsave.Text == "Update")
                {
                    if (getEventStatus != "10")
                        UpdateRoomblock(_eventID, 1);
                    else
                        UpdateRoomblockStatus(_eventID, 1);
                }
            }
			catch (System.Web.Services.Protocols.SoapException ex)
			{
				logger.Error(ex.Detail.InnerText, ex);
			}
            catch (Exception ex)
            {
				logger.Error("btnsave_Click", ex);
            }
        }

        protected void gvFormLoad_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            foreach (TableCell cell in e.Row.Cells)
            {
                if (e.Row.RowIndex >= 0)
                {
                    cell.Attributes["Style"] = "border-color:Gray;padding-left:8px;";
                }
            }

			// Add any holidays to the day or week.
			if (e.Row.RowType == DataControlRowType.DataRow)
			{
				DateTime dt = DateTime.Parse(e.Row.Cells[2].Text);
				String holiday = HelperFunctions.getHoliday(dt, _service, Cache);
				if (String.IsNullOrEmpty(holiday))
					return;

				e.Row.Cells[1].Text += "<br/>(" + holiday + ")";
				e.Row.Cells[1].Attributes["Style"] = "background-color:LightYellow;";
				//logger.InfoFormat("gvFormLoad_RowDataBound() - {0} - {1}", e.Row.Cells[1].Text, e.Row.Cells[2].Text);
			}
        }

#endregion //Events

//#region UserdefinedMethods
        private void Retrieve(OrganizationService _service, bool rpFlag,int onChangeStatus)
        {
            try
            {
				logger.Info("Debug001: 0");
				if (HttpContext.Current.Request.QueryString["recordid"] == null)
                {
					btnsave.Visible = false;
					btnlead.Visible = false;
					return;
				}

				logger.Info("Debug001: 1");
                string getRecordid = Request.QueryString["recordid"].ToString();
                string _eventID = getRecordid.Replace("{", "").Replace("}", "");
				ViewState["_eventID"] = _eventID;
				logger.Info("Debug001: 2");

				// Get the dates from the event.
				var cols = new ColumnSet(new String[] { "new_arrivaldate", "new_departuredate" });
				var evt = (Opportunity)_service.Retrieve("opportunity", new Guid(_eventID), cols);
				DateTime dtArrivalDate = evt.New_arrivaldate ?? DateTime.MinValue;
				DateTime dtdeparture = evt.New_departuredate ?? DateTime.MinValue;
                // ensure whole days
                dtArrivalDate = new DateTime(dtArrivalDate.Year, dtArrivalDate.Month, dtArrivalDate.Day);
                dtdeparture = new DateTime(dtdeparture.Year, dtdeparture.Month, dtdeparture.Day);

				logger.Info("Debug001: 3");
				try
                {
                    EntityCollection entityCollection = CheckRoomPatternecords(_eventID, _service);
                    Hashtable hshTableRoomPattern = new Hashtable();
                    if (entityCollection.Entities.Count > 0)
                    {
                        for (int j = 0; j < entityCollection.Entities.Count; j++)
                        {
                            New_roompattern entity = (New_roompattern)entityCollection.Entities[j];
                            if (entity["bcmc_date"] != null)
                                hshTableRoomPattern.Add("bcmc_date" + j, (entity["bcmc_date"] as DateTime?).Value.ToShortDateString());
                            else
                                hshTableRoomPattern.Add("bcmc_date" + j, "01/01/0001");
                        }
						logger.Info("Debug001: 4");

                        if (hshTableRoomPattern.Count > 0)
                        {
                            string roomblock_ArrivalDate_uniqueFromHash = 
								hshTableRoomPattern["bcmc_date0"].ToString();
                              
                            if (roomblock_ArrivalDate_uniqueFromHash != "01/01/0001")
                            {
								logger.Info("Debug001: 5");
								dtdeparture = dtdeparture.AddDays(-1);
								// If the hashed and actual arriv. and dept. dates are the same...
                                if (hshTableRoomPattern["bcmc_date0"].ToString() == dtArrivalDate.ToShortDateString())
                                {
                                    if (dtdeparture.ToShortDateString() == 
										hshTableRoomPattern["bcmc_date" + (hshTableRoomPattern.Count - 1).ToString()].ToString())
                                    {
                                        dtretrieve = new DataTable();
                                        dtretrieve.Columns.Add("DayNumber");
                                        dtretrieve.Columns.Add("DayofWeek");
                                        dtretrieve.Columns.Add("Date");
                                        dtretrieve.Columns.Add("Original % of Peak");
                                        dtretrieve.Columns.Add("Original Block");
                                        dtretrieve.Columns.Add("Current % of Peak");
                                        dtretrieve.Columns.Add("Current Block");
                                        dtretrieve.Columns.Add("RoomGUID");

										for (int i = 0; i < entityCollection.Entities.Count; i++)
                                        {
											DataRow drretrieves = dtretrieve.NewRow();
                                            New_roompattern entity = (New_roompattern)entityCollection.Entities[i];

                                            drretrieves["RoomGUID"] = (entity["new_roompatternid"] as Guid?).Value.ToString();

                                            if (entity["new_daynumber"] != null)
                                                drretrieves["DayNumber"] = entity["new_daynumber"] as string;
                                            else
                                                drretrieves["DayNumber"] = "0";
                                            if (entity["new_name"] != null)
                                            {
                                                drretrieves["DayofWeek"] = entity["new_name"];
                                            }
                                            if (entity["bcmc_date"] != null)
                                            {
                                                drretrieves["Date"] = (entity["bcmc_date"] as DateTime?).Value.ToShortDateString();
                                            }
                                            if (entity["bcmc_originalpercentofpeak"] != null)
                                            {
                                                drretrieves["Original % of Peak"] = entity.Bcmc_OriginalpercentofPeak;
                                            }

                                            if (entity.New_PercentofPeak != null)
                                            {
                                                drretrieves["Current % of Peak"] = entity.New_PercentofPeak.Value;
                                            }

                                            if (entity.Bcmc_OriginalRoomBlock != null)
                                            {
                                                drretrieves["Original Block"] = entity.Bcmc_OriginalRoomBlock.Value;
                                            }
                                            if (entity.New_RoomBlock != null)
                                            {
                                                    drretrieves["Current Block"] = entity.New_RoomBlock.Value;
                                            }
                                            dtretrieve.Rows.Add(drretrieves);
                                        }
										logger.Info("Debug001: 6");
                                        gvFormLoad.DataSource = dtretrieve;
                                        gvFormLoad.DataBind();
										gvFormLoad.Columns[7].Visible = bSHOW_ROOM_GUID ? true: false; 
                                        gvFormLoad.Columns[0].Visible = false;
                                        gvFormLoad.Visible = true;
                                        if (gvFormLoad.Rows.Count > 0)
                                        {
                                            DataTable dt = new DataTable();
                                            gvRoomBlock.DataSource = dt;
                                            gvRoomBlock.DataBind();
                                            gvRoomBlock.Visible = false;
                                        }
                                        btnsave.Text = "Update";
                                        btnlead.Enabled = true;
                                    }
                                    else
                                    {
										logger.Info("Debug001: 7");
                                        if (onChangeStatus==1)
                                            DeleteRoomblock(_eventID);
                                        RoomBlockGrid();
                                    }
                                }
                                else
                                {
									logger.Info("Debug001: 8");
                                    if (onChangeStatus == 1)
                                        DeleteRoomblock(_eventID);
                                    RoomBlockGrid();
                                }
                            }
                            else
                            {
								logger.Info("Debug001: 9");
                                DisplayNullDateRecords(entityCollection);
                            }
                        }
                    }
                    else
                    {
						logger.Info("Debug001: 10");
                        RoomBlockGrid();
                    }
                }
				catch (System.Web.Services.Protocols.SoapException ex)
				{
					logger.Error(ex.Detail.InnerText, ex);
				}
                catch (Exception ex)
                {
                    logger.Error("Dynamicgridview Page: Retrieve Roomblock  Method: Error" + ex.ToString());
                }
            }
			catch (System.Web.Services.Protocols.SoapException ex)
            {
				logger.Error(ex.Detail.InnerText, ex);
            }
            catch (Exception ex)
            {
                logger.Error("Roomblock:" + ex.ToString());
			}
			finally
			{
            }
        }

        private void DisplayNullDateRecords(EntityCollection entityCollection)
        {
            try
            {
                New_roompattern entity = new New_roompattern();
                dtretrieve = new DataTable();
                dtretrieve.Columns.Add("DayNumber");
                dtretrieve.Columns.Add("DayofWeek");
                dtretrieve.Columns.Add("Date");
                dtretrieve.Columns.Add("Original % of Peak");
                dtretrieve.Columns.Add("Original Block");
                dtretrieve.Columns.Add("Current % of Peak");
                dtretrieve.Columns.Add("Current Block");
                dtretrieve.Columns.Add("RoomGUID");
                for (int i = 0; i < entityCollection.Entities.Count; i++)
                {
                    DataRow drretrieves = dtretrieve.NewRow();

                    entity = (New_roompattern)entityCollection.Entities[i];

                    drretrieves["RoomGUID"] = entity.New_roompatternId.Value.ToString();

                    if (entity.New_DayNumber != null)
                    {
                        drretrieves["DayNumber"] = entity.New_DayNumber.Value;
                    }
                    else
                    {
                        drretrieves["DayNumber"] = "0";
                    }
                    if (entity.New_name != null)
                    {
                        drretrieves["DayofWeek"] = entity.New_name;
                    }
                    if (entity.Bcmc_Date != null)
                    {
                        drretrieves["Date"] = entity.Bcmc_Date.Value.ToShortDateString();
                    }
                    if (entity.Bcmc_OriginalpercentofPeak != null)
                    {
                        drretrieves["Original % of Peak"] = entity.Bcmc_OriginalpercentofPeak.Value;
                    }
                    if (entity.New_PercentofPeak != null)
                    {
                        drretrieves["Current % of Peak"] = entity.New_PercentofPeak.Value;
                    }

                    if (entity.Bcmc_OriginalRoomBlock != null)
                    {
                        drretrieves["Original Block"] = entity.Bcmc_OriginalRoomBlock.Value;
                    }
                    if (entity.New_RoomBlock != null)
                    {
                        drretrieves["Current Block"] = entity.New_RoomBlock.Value;
                    }
                    dtretrieve.Rows.Add(drretrieves);
                }
                gvFormLoad.DataSource = dtretrieve;
                gvFormLoad.DataBind();
				gvFormLoad.Columns[7].Visible = bSHOW_ROOM_GUID ? true : false;
                gvFormLoad.Columns[0].Visible = false;
                gvFormLoad.Visible = true;
                if (gvFormLoad.Rows.Count > 0)
                {
                    gvRoomBlock.DataSource = new DataTable();
                    gvRoomBlock.DataBind();
                    gvRoomBlock.Visible = false;
                }

                ViewState["DisplayDateisNULL"] = "DisplayDateisNULL";
            }
			catch (System.Web.Services.Protocols.SoapException ex)
			{
				logger.Error(ex.Detail.InnerText, ex);
			}
            catch (Exception ex)
            {
                logger.Error("DisplayNullDateRecords " + ex.ToString()); 
            }             
        }

        private void DeleteRoomblock(string eventid)
        {
            try
            {
                string Eventid = eventid;

                ColumnSet columnSet = new ColumnSet(new string[] { "new_roompatternid" });

                ConditionExpression condition = new ConditionExpression();
                condition.AttributeName = "new_eventid";
                condition.Operator = ConditionOperator.Equal;
                condition.Values.Add(Eventid);

                FilterExpression filter = new FilterExpression();
                filter.Conditions.Add(condition);

                QueryExpression query = new QueryExpression();
                query.ColumnSet = columnSet;
                query.Criteria = filter;
                query.EntityName = New_roompattern.EntityLogicalName;

                EntityCollection entityCollection = _service.RetrieveMultiple(query);
                if (entityCollection.Entities.Count > 0)
                {
                    for (int j = 0; j < entityCollection.Entities.Count; j++)
                    {
                        New_roompattern entity = (New_roompattern)entityCollection.Entities[j];
                        if (entity != null)
                        {
							_service.Delete(New_roompattern.EntityLogicalName, new Guid(entity.New_roompatternId.Value.ToString()));
                        }
                    }
                }
            }
			catch (System.Web.Services.Protocols.SoapException ex)
			{
				logger.Error(ex.Detail.InnerText, ex);
			}
            catch (Exception ex)
            {
                logger.Error("DeleteRoomblock " + ex.ToString());
            }
        }

        private void RoomBlockGrid()
        {
            try
            {
				Build_RoomBlock_Datatable();
				gvRoomBlock.DataSource = dtRoomBlock;
                gvRoomBlock.DataBind();
                gvRoomBlock.Columns[0].Visible = false;
				gvRoomBlock.Columns[7].Visible = bSHOW_ROOM_GUID ? true : false;
				gvRoomBlock.Columns[8].Visible = bSHOW_ROOM_GUID ? true : false;
                if (gvFormLoad.Rows.Count > 0)
                {
					gvFormLoad.DataSource = new DataTable(); ;
                    gvFormLoad.DataBind();
                    gvFormLoad.Visible = false;
                }
            }
			catch (System.Web.Services.Protocols.SoapException ex)
			{
				logger.Error(ex.Detail.InnerText, ex);
            }
            catch (Exception ex)
            {
                logger.Error("RoomBlockGrid" + ex.ToString());
            }
			finally
			{
			}
        }

        private void RetrieveBasedonStatus(OrganizationService _service)
        {
            try
            {
				if (HttpContext.Current.Request.QueryString["recordid"] == null)
                {
					btnsave.Visible = false;
					btnlead.Visible = false;
				}

                string getRecordid = Request.QueryString["recordid"].ToString();
                string _eventID = getRecordid.Replace("{", "").Replace("}", "");
                ViewState["_eventID"] = _eventID;

				// Get the dates from the event.
				var cols = new ColumnSet(new String[] { "new_arrivaldate", "new_departuredate" });
				var evt = (Opportunity)_service.Retrieve("opportunity", new Guid(_eventID), cols);
				DateTime _arrivaldatedt = evt.New_arrivaldate ?? DateTime.MinValue;
				DateTime _departuredatedt = evt.New_departuredate ?? DateTime.MinValue;

                try
                {
                    New_roompattern entity = new New_roompattern();
                    EntityCollection entityCollection = CheckRoomPatternecords(_eventID, _service);
                    Hashtable hshTableRoomPattern = new Hashtable();
                    if (entityCollection.Entities.Count > 0)
                    {
                        for (int j = 0; j < entityCollection.Entities.Count; j++)
                        {
                            entity = (New_roompattern)entityCollection.Entities[j];
                            if (entity.Bcmc_Date != null)
                                hshTableRoomPattern.Add("bcmc_date" + j, entity.Bcmc_Date.Value.ToShortDateString());
                            else
                                hshTableRoomPattern.Add("bcmc_date" + j, "01/01/0001");
                        }

                        if (hshTableRoomPattern.Count > 0)
                        {
                            string tempArrivalDateRoomPattern = hshTableRoomPattern["bcmc_date0"].ToString();
                            string tempDepartureDateRoomPattern = hshTableRoomPattern["bcmc_date" + (hshTableRoomPattern.Count - 1).ToString()].ToString();

#region Bind Grid
                            if (true)
                            {
                                if (true)
                                {
                                    dtretrieve = new DataTable();
                                    dtretrieve.Columns.Add("DayNumber");
                                    dtretrieve.Columns.Add("DayofWeek");
                                    dtretrieve.Columns.Add("Date");
                                    dtretrieve.Columns.Add("Original % of Peak");
                                    dtretrieve.Columns.Add("Original Block");
                                    dtretrieve.Columns.Add("Current % of Peak");
                                    dtretrieve.Columns.Add("Current Block");
                                    dtretrieve.Columns.Add("RoomGUID");
                                    dtretrieve.Columns.Add("GUIDID");

                                    for (int i = 0; i < entityCollection.Entities.Count; i++)
                                    {
                                        DataRow drretrieves = dtretrieve.NewRow();
                                        entity = (New_roompattern)entityCollection.Entities[i];

                                        drretrieves["RoomGUID"] = entity.New_roompatternId.Value.ToString();
                                        drretrieves["GUIDID"] = _eventID.ToString();

                                        if (entity.New_DayNumber != null)
                                            drretrieves["DayNumber"] = entity.New_DayNumber.Value;
                                        else
                                            drretrieves["DayNumber"] = "0";

                                        if (entity.New_name != null)
                                            drretrieves["DayofWeek"] = entity.New_name;

                                        if (entity.Bcmc_Date != null)
                                            drretrieves["Date"] = entity.Bcmc_Date.Value.ToShortDateString();

                                        if (entity.Bcmc_OriginalpercentofPeak != null)
                                        {
                                            drretrieves["Original % of Peak"] = entity.Bcmc_OriginalpercentofPeak.Value;

                                            btnsave.Text = "Update";
                                            btnlead.Enabled = true;
                                        }

                                        if (entity.Bcmc_OriginalRoomBlock != null)
                                        {
                                            drretrieves["Original Block"] = entity.Bcmc_OriginalRoomBlock.Value;

                                            btnsave.Text = "Update";
                                            btnlead.Enabled = true;
                                        }

                                        if (entity.New_PercentofPeak != null)
                                        {
                                            drretrieves["Current % of Peak"] = entity.New_PercentofPeak.Value;

                                            btnsave.Text = "Update";
                                            btnlead.Enabled = true;
                                        }

										if (entity.New_RoomBlock != null)
                                        {
                                            drretrieves["Current Block"] = entity.New_RoomBlock.Value;

                                            btnsave.Text = "Update";
                                            btnlead.Enabled = true;
                                        }

                                        dtretrieve.Rows.Add(drretrieves);
                                    }

                                    gvFormLoad.DataSource = dtretrieve;
                                    gvFormLoad.DataBind();

                                    bool dateFLag = false;

                                    Hashtable hshDateCollections = new Hashtable();
                                    for (int i = 0; i < dtretrieve.Rows.Count; i++)
                                    {
                                        string getDate = dtretrieve.Rows[i]["Date"].ToString();
                                        string roomID = dtretrieve.Rows[i]["RoomGUID"].ToString();
                                        //Added this code for check the existing records in crm, 
										//if those records does not having the date and has null means, we check the record and update it.

                                        EntityCollection rp_Records_Entities = FindRoomPatternDates(_eventID, _service);
                                        if (rp_Records_Entities.Entities.Count == 0)
                                        {
											if (!CheckDateExists(_arrivaldatedt.ToShortDateString(), _departuredatedt.ToShortDateString(), getDate))
                                            {
                                                New_roompattern roomEvent = new New_roompattern();
                                                roomEvent.New_roompatternId = new Guid(roomID);
                                                int currntroomblock = 0;
                                                roomEvent.New_RoomBlock = currntroomblock;
                                                dtretrieve.Rows[i]["Current Block"] = "";
                                                roomEvent.New_PercentofPeak = 0;
                                                dtretrieve.Rows[i]["Current % of Peak"] = "";
                                                //Commented by ZSL Team on July 27th 2012
												//  _service.Update(roomEvent);*/
                                            }
                                        }
                                        else
                                        {
                                            dateFLag = true;
											hshDateCollections = ProcessDateIsNull(_arrivaldatedt.ToShortDateString(), _departuredatedt.ToShortDateString());
                                            break;
                                        }
                                    }
                                    dtRoomBlock = dtretrieve;
                                    gvFormLoad.DataSource = dtretrieve;
                                    gvFormLoad.DataBind();

                                    for (int i = 0; i < dtretrieve.Rows.Count; i++)
                                    {
                                        string getDate = dtretrieve.Rows[i]["Date"].ToString();
                                        string roomID = dtretrieve.Rows[i]["RoomGUID"].ToString();

										if (!dateFLag && !CheckDateExists(_arrivaldatedt.ToShortDateString(), _departuredatedt.ToShortDateString(), getDate))
                                        {
                                            gvFormLoad.Rows[i].Enabled = false;
                                        }
									}
									gvFormLoad.Columns[7].Visible = bSHOW_ROOM_GUID ? true : false;
									gvFormLoad.Columns[0].Visible = bSHOW_ROOM_GUID ? true : false;
                                    gvFormLoad.Visible = true;

                                    if (gvFormLoad.Rows.Count > 0)
                                    {
                                        DataTable dt = new DataTable();
                                        gvRoomBlock.DataSource = dt;
                                        gvRoomBlock.DataBind();
                                        gvRoomBlock.Visible = false;
                                    }
                                }
                            }
	#endregion
                        }
                    }
                    else
                    {
                        RoomBlockGrid();
                    }
                }
				catch (System.Web.Services.Protocols.SoapException ex)
				{
					logger.Error(ex.Detail.InnerText, ex);
				}
                catch (Exception ex)
                {
					logger.Error("720 RetrieveBasedonStatus" + ex.ToString());
                }
			}
			catch (System.Web.Services.Protocols.SoapException ex)
            {
				logger.Error(ex.Detail.InnerText, ex);
            }
			catch (Exception ex)
			{
				logger.Error("721 RetrieveBasedonStatus" + ex.ToString());
            }
			finally
            {
            }
        }

        private Hashtable ProcessDateIsNull(string _arrivaldate, string __departuredate)
        {
            Hashtable hshDateCollections = new Hashtable();
            try
            {
				logger.Info("750 Dynamicgridview Page:  ProcessDateIsNull   Method: Started");
                DateTime departureDate = Convert.ToDateTime((Convert.ToDateTime(__departuredate)).ToString("MM/dd/yyyy"));
				//logger.Info("CheckDateExists Method: ProcessDateIsNull:Departure Date: " + departureDate);
                DateTime arrivalDate = Convert.ToDateTime((Convert.ToDateTime(_arrivaldate)).ToString("MM/dd/yyyy"));
				//logger.Info("CheckDateExists Method: ProcessDateIsNull:Arrival Date: " + departureDate);

                TimeSpan dtTime = departureDate.Subtract(arrivalDate);

                for (int i = 0; i < Math.Floor(dtTime.TotalDays); i++)
                {
                    hshDateCollections.Add(i, arrivalDate.AddDays(i).ToString("MM/dd/yyyy"));
                }
				//logger.Info("ProcessDateIsNull Method: compared dates Failed. No Same dates found.");
            }
			catch (System.Web.Services.Protocols.SoapException ex)
			{
				logger.Error(ex.Detail.InnerText, ex);
			}
            catch (Exception ex)
            {
                logger.Error("ProcessDateIsNull Method: Error" + ex.ToString());
                // throw;
            }
            return hshDateCollections;
        }

        private bool CheckDateExists(string _arrivaldate, string __departuredate, string currentArrDate)
        {
            try
            {
                DateTime departureDate = Convert.ToDateTime((Convert.ToDateTime(__departuredate)).ToString("MM/dd/yyyy"));
                DateTime arrivalDate = Convert.ToDateTime((Convert.ToDateTime(_arrivaldate)).ToString("MM/dd/yyyy"));
                DateTime getArrDate = Convert.ToDateTime((Convert.ToDateTime(currentArrDate)).ToString("MM/dd/yyyy"));
                TimeSpan dtTime = departureDate.Subtract(arrivalDate);

				for (int i = 0; i < Math.Floor(dtTime.TotalDays); i++)
                {
                    if (getArrDate.ToString("MM/dd/yyyy") == arrivalDate.AddDays(i).ToString("MM/dd/yyyy"))
                    {
                        return true;
                    }
                }
            }
			catch (System.Web.Services.Protocols.SoapException ex)
			{
				logger.Error(ex.Detail.InnerText, ex);
			}
            catch (Exception ex)
            {
                logger.Error("CheckDateExists Method: Error" + ex.ToString());
                // throw;
            }
            return false;
        }

        private string CheckEventStatus(OrganizationService _service, string getRecordid)
        {
            string getstatusCode = "";
            try
            {
                ColumnSet columnSet = new ColumnSet(new string[] { "bcmc_eventname", "statuscode" });

                ConditionExpression condition_new_eventid = new ConditionExpression();
                condition_new_eventid.AttributeName = "opportunityid";
                condition_new_eventid.Operator = ConditionOperator.Equal;
                condition_new_eventid.Values.Add(getRecordid);

                FilterExpression filter_Eventid = new FilterExpression();
                filter_Eventid.Conditions.Add(condition_new_eventid);

                // Create the query.
                QueryExpression query = new QueryExpression();

                // Set the properties of the query.
                query.ColumnSet = columnSet;
                query.Criteria = filter_Eventid;
                query.EntityName = Opportunity.EntityLogicalName;

                EntityCollection entityCollection = _service.RetrieveMultiple(query);
                Hashtable hshTableOpportunity = new Hashtable();
                if (entityCollection.Entities.Count > 0)
                {
                    for (int j = 0; j < entityCollection.Entities.Count; j++)
                    {
                        Opportunity opportunity = (Opportunity)entityCollection.Entities[j];
                        getstatusCode = opportunity.StatusCode.Value.ToString();
                    }
                }
            }
			catch (System.Web.Services.Protocols.SoapException ex)
			{
				logger.Error(ex.Detail.InnerText, ex);
			}
            catch (Exception ex)
            {

                logger.Error("CheckEventStatus Method" + ex.ToString());
            }

            return getstatusCode;
        }

		private EntityCollection CheckRoomPatternecords(string _eventID, OrganizationService _service)
        {
			ConditionExpression condition_new_eventid = new ConditionExpression();
            condition_new_eventid.AttributeName = "new_eventid";
            condition_new_eventid.Operator = ConditionOperator.Equal;
            condition_new_eventid.Values.Add(_eventID);

            OrderExpression ordeErp = new OrderExpression();
            ordeErp.AttributeName = "bcmc_date";
            ordeErp.OrderType = OrderType.Ascending;

            FilterExpression filter_Eventid = new FilterExpression();
            filter_Eventid.Conditions.Add(condition_new_eventid);

            QueryExpression query = new QueryExpression();
            query.ColumnSet.AddColumns(new string[] { 
				"new_daynumber", 
				"new_name", 
				"bcmc_date", 
				"new_percentofpeak", 
				"bcmc_originalpercentofpeak", 
				"bcmc_originalroomblock", 
				"new_roomblock" });
            query.Criteria = filter_Eventid;
            query.Orders.Add(ordeErp);
            query.EntityName = New_roompattern.EntityLogicalName;

            EntityCollection entityCollection = _service.RetrieveMultiple(query);
            return entityCollection;
        }

        private EntityCollection FindRoomPatternDates(string _eventID, OrganizationService _service)
        {
			ColumnSet columnSet = new ColumnSet(new string[] { 
				"new_daynumber", 
				"new_name", 
				"bcmc_date", 
				"new_percentofpeak", 
				"bcmc_originalpercentofpeak", 
				"bcmc_originalroomblock", 
				"new_roomblock" });
            ConditionExpression condition_new_eventid = new ConditionExpression();
            condition_new_eventid.AttributeName = "new_eventid";
            condition_new_eventid.Operator = ConditionOperator.Equal;
            condition_new_eventid.Values.Add(_eventID);

            ConditionExpression condition_date = new ConditionExpression();
            condition_date.AttributeName = "bcmc_date";
            condition_date.Operator = ConditionOperator.Null;

            FilterExpression filter_Eventid = new FilterExpression();
            filter_Eventid.FilterOperator = LogicalOperator.And;
            filter_Eventid.Conditions.AddRange( new ConditionExpression[] { condition_new_eventid, condition_date });

            QueryExpression query = new QueryExpression();
            query.ColumnSet = columnSet;
            query.Criteria = filter_Eventid;
            query.EntityName = New_roompattern.EntityLogicalName;

			EntityCollection entityCollection = _service.RetrieveMultiple(query);
            return entityCollection;
        }

        private void BindSave(string _eventID)
        {
            try
            {
                Guid crmguid = Guid.Empty;

                for (int i = 0; i < gvRoomBlock.Rows.Count; i++)
                {
                    int daynumber = Convert.ToInt32(dtRoomBlock.Rows[i]["DayNumber"]);
                    string new_week = dtRoomBlock.Rows[i]["DayofWeek"].ToString();

                    DateTime roomblockdate = Convert.ToDateTime(dtRoomBlock.Rows[i]["Date"]);

					int new_originalpeak = 0;
					System.Web.UI.WebControls.Label lblOriginalPeak = (System.Web.UI.WebControls.Label)(gvRoomBlock.Rows[i].FindControl("lblOPeak"));
                    if (null != lblOriginalPeak.Text && lblOriginalPeak.Text != string.Empty)
                    {
						if (lblOriginalPeak.Text.Contains("."))
							new_originalpeak = Convert.ToInt32(lblOriginalPeak.Text.Split('.')[0].ToString());
                        else
							new_originalpeak = Convert.ToInt32(lblOriginalPeak.Text);
                    }

                    int new_Original = 0;
					System.Web.UI.WebControls.Label labelOriginalBlock = (System.Web.UI.WebControls.Label)(gvRoomBlock.Rows[i].FindControl("lblOblock"));
                    if (null != labelOriginalBlock.Text && labelOriginalBlock.Text != string.Empty)
                    {
                        new_Original = Convert.ToInt32(labelOriginalBlock.Text);
                    }

                    int new_percentofpeak = 0;
					HiddenField hdnFld = (HiddenField)(gvRoomBlock.Rows[i].FindControl("hdnfdValue"));
                    if (null != hdnFld.Value && hdnFld.Value != string.Empty)
                    {
                        if (hdnFld.Value.Contains("."))
                            new_percentofpeak = Convert.ToInt32(hdnFld.Value.Split('.')[0].ToString());
                        else
                            new_percentofpeak = Convert.ToInt32(hdnFld.Value);
                    }

                    int new_Current = 0;
					TextBox txtBoxCurrent = (TextBox)(gvRoomBlock.Rows[i].FindControl("txtCBlock"));
                    if (null != txtBoxCurrent.Text && txtBoxCurrent.Text != string.Empty)
                    {
						new_Current = Convert.ToInt32(txtBoxCurrent.Text);
                    }

                    EntityReference new_eventid = 
						new EntityReference("opportunity", new Guid(_eventID));

                    Entity myroomblock = new Entity(New_roompattern.EntityLogicalName);
					myroomblock["new_daynumber"] = daynumber;
					myroomblock["new_name"] = new_week;
					myroomblock["bcmc_date"] = roomblockdate;
					myroomblock["bcmc_originalpercentofpeak"] = new_originalpeak;
					myroomblock["bcmc_originalroomblock"] = new_Original;
					myroomblock["new_percentofpeak"] = new_percentofpeak;
					myroomblock["new_roomblock"] = new_Current;
					myroomblock["new_eventid"] = new_eventid;
					myroomblock["bcmc_user"] = this.Username;

					crmguid = _service.Create(myroomblock);
					logger.Info("990 BindSave new_roomblockid= " + crmguid.ToString());

					dtRoomBlock.Rows[i]["RoomGUID"] = crmguid.ToString();

					/* Not necessary as Sync is done in 'Retrieve' below
					// Sync corresponding datatable to refresh gridview with new guids.
                    dtRoomBlock.Rows[i]["RoomGUID"] = crmguid.ToString();
					dtRoomBlock.Rows[i]["DayNumber"] = daynumber.ToString();
					dtRoomBlock.Rows[i]["DayofWeek"] = new_week;
					dtRoomBlock.Rows[i]["Date"] = roomblockdate.ToShortDateString();
					dtRoomBlock.Rows[i]["Original % of Peak"] = new_originalpeak.ToString();
					dtRoomBlock.Rows[i]["Current % of Peak"] = new_percentofpeak.ToString();
					dtRoomBlock.Rows[i]["Original Block"] = new_Original.ToString();
					dtRoomBlock.Rows[i]["Current Block"] = new_Current.ToString();
					//GUIDID
					*/ 
				}
				/* Not necessary as Sync is done in 'Retrieve' below
				// Sync Grid, with new guids
				gvRoomBlock.DataSource = dtRoomBlock;
				gvRoomBlock.DataBind();
				*/ 

				String jsCode = BindPeakroom(gvRoomBlock, _eventID);

                if (crmguid != Guid.Empty)
                {
					string myscript = jsCode + "alert('Successfully saved ');";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "myscript", myscript, true);
                    btnsave.Text = "Update";
                    btnlead.Enabled = true;
                }
				logger.Info("Debug001: BindSave1");
                Retrieve(_service, true, 0);
                btnlead.Enabled = true;
            }
			catch (System.Web.Services.Protocols.SoapException ex)
			{
				logger.Error(ex.Detail.InnerText, ex);
			}
            catch (Exception ex)
            {
                logger.Error("SaveBind: " + ex.ToString());
            }
        }

		private void UpdateRoomblock(string _eventID, int Updatestatus)
        {
            try
            {
                if (gvFormLoad.Rows.Count > 0)
                {
                    for (int i = 0; i < gvFormLoad.Rows.Count; i++)
                    {
                        New_roompattern roompattern = new New_roompattern();
						string RoomGUID = //gvFormLoad.Rows[i].Cells[7].Text;
							dtretrieve.Rows[i]["RoomGUID"].ToString();
						roompattern.New_roompatternId = new Guid(RoomGUID);
						logger.Info("1165 UpdateRoomBlockGrid.RoomPatternGuid= " + RoomGUID);

                        HiddenField txtcurrentpercent = (HiddenField)gvFormLoad.Rows[i].FindControl("hdnfdValue");
                        string CPeak = txtcurrentpercent.Value;
                        int intCPeak = 0;
                        if (null != txtcurrentpercent &&
							txtcurrentpercent.Value != string.Empty)
                        {
                            if (CPeak.Contains("."))
                                intCPeak = Convert.ToInt32(CPeak.Split('.')[0].ToString());
                            else
                                intCPeak = Convert.ToInt32(CPeak);
                        }
                        roompattern.New_PercentofPeak = intCPeak;

						TextBox txtcurrentroom = (TextBox)gvFormLoad.Rows[i].FindControl("txtCBlock");
						string CRoom = txtcurrentroom.Text;
                        int intCRoom = 0;
                        if (null != txtcurrentroom 
							&& txtcurrentroom.Text != string.Empty)
                        {
                            if (CRoom.Contains("."))
                                intCRoom = Convert.ToInt32(CRoom.Split('.')[0].ToString());
                            else
                                intCRoom = Convert.ToInt32(CRoom);
                        }
                        roompattern.New_RoomBlock = intCRoom;
						logger.Info("1180  roompattern.new_roomblock (Current RoomBlock)= " + roompattern.New_RoomBlock);

						roompattern["bcmc_user"] = this.Username;
                        _service.Update(roompattern);
                    }

					// Update an attribute retrieved via RetrieveAttributeRequest
					String jsCode = BindPeakroom(gvFormLoad, _eventID);
                    if (Updatestatus == 1)
                    {
						string myscript = jsCode + "alert('Successfully updated ');";
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "myscript", myscript, true);
                    }

					logger.Info("Debug001: UpdateRoomblock1");
					Retrieve(_service, true, 0);
                    btnlead.Enabled = true;
                }
                else if (gvRoomBlock.Rows.Count > 0)
                {
                    for (int i = 0; i < gvRoomBlock.Rows.Count; i++)
                    {
                        // Create the RoomPattern object.
                        New_roompattern roompattern = new New_roompattern();
						string RoomGUID = //gvRoomBlock.Rows[i].Cells[8].Text; 
							dtretrieve.Rows[i]["RoomGUID"].ToString();
						roompattern.New_roompatternId = new Guid(RoomGUID);

						// Set the RoomPattern object properties to be updated.
						HiddenField txtcurrentpercent = (HiddenField)gvRoomBlock.Rows[i].FindControl("hdnfdValue");
						string CPeak = txtcurrentpercent.Value;
						int intCPeak = 0;
						if (null != txtcurrentpercent && (txtcurrentpercent.Value != string.Empty))
                        {
                            if (CPeak.Contains("."))
                            {
                                intCPeak = Convert.ToInt32(CPeak.Split('.')[0].ToString());
                            }
                            else
                            {
                                intCPeak = Convert.ToInt32(CPeak);
                            }
                        }
                        roompattern.New_PercentofPeak = intCPeak;

                        TextBox txtcurrentroom = (TextBox)gvRoomBlock.Rows[i].FindControl("txtCBlock");
                        string CRoom = txtcurrentroom.Text;
                        int intCRoom = 0;
                        if (null != txtcurrentroom &&
							txtcurrentroom.Text != string.Empty)
                        {
                            if (CRoom.Contains("."))
                            {
                                intCRoom = Convert.ToInt32(CRoom.Split('.')[0].ToString());
                            }
                            else
                            {
                                intCRoom = Convert.ToInt32(CRoom);
                            }
                        }
						roompattern.New_RoomBlock = intCRoom;

						if (_service != null)
						{
							roompattern["bcmc_user"] = this.Username;
							_service.Update(roompattern);
						}
                    }

					String jsCode = BindPeakroom(gvRoomBlock, _eventID);
					Page.ClientScript.RegisterStartupScript(this.GetType(), "myscript",
						jsCode + "alert('Successfully updated ');", 
						true);

					logger.Info("Debug001: pageload2");
					Retrieve(_service, true, 0);
					btnlead.Enabled = true;
				}
			}
			catch (System.Web.Services.Protocols.SoapException ex)
            {
				logger.Error(ex.Detail.InnerText, ex);
			}
			catch (Exception ex)
            {
				logger.Error("1251 UpdateRoomblock " + ex.ToString());
            }
		}

#region 
		private void UpdateRoomblockStatus1(string _eventID, int Updatestatus)
		{
			try
			{
				string getRecordid = Request.QueryString["recordid"].ToString();

				// Get the dates from the event.
				var cols = new ColumnSet(new String[] { "new_arrivaldate", "new_departuredate" });
				var evt = (Opportunity)_service.Retrieve("opportunity", new Guid(getRecordid), cols);
				DateTime _arrivaldatedt = evt.New_arrivaldate ?? DateTime.MinValue;
				DateTime _departuredatedt = evt.New_departuredate ?? DateTime.MinValue;
                // ensure whole days
                _arrivaldatedt = new DateTime(_arrivaldatedt.Year, _arrivaldatedt.Month, _arrivaldatedt.Day);
                _departuredatedt = new DateTime(_departuredatedt.Year, _departuredatedt.Month, _departuredatedt.Day);

				logger.Info("1260 Dynamicgridview Page:  Update Roomblock Status Method: Started");

				// Define the entity attributes (database table columns) that are to be retrieved.

				New_roompattern entity = new New_roompattern();

				EntityCollection entityCollection = CheckRoomPatternecords(_eventID, _service);
				logger.Info("1270 Dynamicgridview Page:  Update Roomblock Status Method: After service execution");
				Hashtable hshTableRoomPattern = new Hashtable();

				if (entityCollection.Entities.Count == 0)
					return;

				logger.Info("1280 Dynamicgridview Page: entityCollection.BusinessEntities.Length:: " + entityCollection.Entities.Count);

				for (int j = 0; j < entityCollection.Entities.Count; j++)
				{
					entity = (New_roompattern)entityCollection.Entities[j];
					// logger.Info("Dynamicgridview Page:  Retrieve Roomblock  Method: Retrieve Rooom Pattern Entity Value " + entity);


					//Added by ZSL Team on 28-06-2012
					if (entity.Bcmc_Date != null)
						hshTableRoomPattern.Add("bcmc_date" + j, entity.Bcmc_Date.Value.ToShortDateString());
					else
						hshTableRoomPattern.Add("bcmc_date" + j, "01/01/0001");
				}

				if (hshTableRoomPattern.Count > 0)
				{
					string tempArrivalDateRoomPattern = hshTableRoomPattern["bcmc_date0"].ToString();


					if (tempArrivalDateRoomPattern != "01/01/0001")
					{
						logger.Info("1290 Dynamicgridview Page:  Update Roomblock Status Method: Retrieve Rooom Pattern ArrivalDate " + hshTableRoomPattern["bcmc_date0"].ToString());
						string tempDepartureDateRoomPattern = hshTableRoomPattern["bcmc_date" + (hshTableRoomPattern.Count - 1).ToString()].ToString();
						logger.Info("1300 Dynamicgridview Page:  Update Roomblock Status  Method: Retrieve Rooom Pattern ArrivalDate " + hshTableRoomPattern["bcmc_date" + (hshTableRoomPattern.Count - 1).ToString()].ToString());

						DateTime dtdeparture = _departuredatedt;
						dtdeparture = dtdeparture.AddDays(-1);
						string _Departuredate = Convert.ToString(dtdeparture.ToShortDateString());
						DateTime dtTempDepTime = Convert.ToDateTime(tempDepartureDateRoomPattern);
						DateTime dtDeparturedate = Convert.ToDateTime(_Departuredate);

						DateTime dtTempArrTime = Convert.ToDateTime(tempArrivalDateRoomPattern);
						DateTime dtArrivalDate = _arrivaldatedt;

						logger.Info("1310 Arrival Date Check dtArrivalDate: + " + dtArrivalDate.ToString());
						logger.Info("1320 Arrival Date Check dtTempArrTime: + " + dtTempArrTime.ToString());

						if (gvFormLoad.Rows.Count > 0)
						{
							for (int i = 0; i < gvFormLoad.Rows.Count; i++)
							{
								// Create the RoomPattern object.
								New_roompattern roompattern = new New_roompattern();
								string RoomGUID = //gvFormLoad.Rows[i].Cells[7].Text; 
									dtretrieve.Rows[i]["RoomGUID"].ToString();
								roompattern.New_roompatternId = new Guid(RoomGUID);

								// Set the RoomPattern object properties to be updated.
								HiddenField txtcurrentpercent = (HiddenField)gvFormLoad.Rows[i].FindControl("hdnfdValue");
								string CPeak = txtcurrentpercent.Value;
								int intCPeak = 0;
								if ((((HiddenField)(gvFormLoad.Rows[i].FindControl("hdnfdValue"))).Value != string.Empty) && ((HiddenField)(gvFormLoad.Rows[i].FindControl("hdnfdValue"))) != null)
								{
									if (CPeak.Contains("."))
									{
										intCPeak = Convert.ToInt32(CPeak.Split('.')[0].ToString());
									}
									else
									{
										intCPeak = Convert.ToInt32(CPeak);
									}
								}
								roompattern.New_PercentofPeak = intCPeak;

								string CRoom = "0";
								int intCRoom = 0;
								if (gvFormLoad.Rows[i].Enabled == true)
								{
									TextBox txtcurrentroom = (TextBox)gvFormLoad.Rows[i].FindControl("txtCBlock");
									CRoom = txtcurrentroom.Text;
									if ((((TextBox)(gvFormLoad.Rows[i].FindControl("txtCBlock"))).Text != string.Empty) && ((TextBox)(gvFormLoad.Rows[i].FindControl("txtCBlock"))).Text != null)
									{
										if (CRoom.Contains("."))
											intCRoom = Convert.ToInt32(CRoom.Split('.')[0].ToString());
										else
											intCRoom = Convert.ToInt32(CRoom);
									}
									else
										roompattern.New_RoomBlock = intCRoom;

									logger.Info("1340 roompattern.new_roomblock  " + roompattern.New_RoomBlock);

									// The RoomPatternid is a key that references the ID of the RoomPattern to be updated.
									// Update the RoomPattern.
									logger.Info("1350 roompattern.new_percentofpeak = " + roompattern.New_PercentofPeak + "- roompattern.new_roomblock " + roompattern.New_RoomBlock);
								}
								else
								{
									//For Diasbled Records Current RoomBlock value set to zero  .
									//ADD By ZSL TEAM  ON 16/Aug/2012
									intCRoom = 0;
									roompattern.New_RoomBlock = intCRoom;
									logger.Info("1360 roompattern.new_roomblock  " + roompattern.New_RoomBlock);
								}

								int intdaynumber = i + 1;
								roompattern.New_DayNumber = intdaynumber;
								roompattern["bcmc_user"] = this.Username;
								_service.Update(roompattern);
							}

							String jsCode = BindPeakroom(gvFormLoad, _eventID);
							if (Updatestatus == 1)
							{
								string myscript = jsCode + "alert('Successfully updated ');";
								Page.ClientScript.RegisterStartupScript(this.GetType(), "myscript", myscript, true);
							}

							RetrieveBasedonStatus(_service);
							btnlead.Enabled = true;
                        }
						else if (gvRoomBlock.Rows.Count > 0)
						{
							for (int i = 0; i < gvRoomBlock.Rows.Count; i++)
							{
								// Create the RoomPattern object.
								New_roompattern roompattern = new New_roompattern();

								// Set the RoomPattern object properties to be updated.
								HiddenField txtcurrentpercent = (HiddenField)gvRoomBlock.Rows[i].FindControl("hdnfdValue");
								string CPeak = txtcurrentpercent.Value;
								int intCPeak = 0;
								if ((((HiddenField)(gvRoomBlock.Rows[i].FindControl("hdnfdValue"))).Value != string.Empty) && ((HiddenField)(gvRoomBlock.Rows[i].FindControl("hdnfdValue"))) != null)
								{
									if (CPeak.Contains("."))
										intCPeak = Convert.ToInt32(CPeak.Split('.')[0].ToString());
									else
										intCPeak = Convert.ToInt32(CPeak);
								}
								roompattern.New_PercentofPeak = intCPeak;
								logger.Info("1410  roompattern.new_percentofpeak = " + roompattern.New_PercentofPeak);

								TextBox txtcurrentroom = (TextBox)gvRoomBlock.Rows[i].FindControl("txtCBlock");
								string CRoom = txtcurrentroom.Text;
								int intCRoom = 0;
								if ((((TextBox)(gvRoomBlock.Rows[i].FindControl("txtCBlock"))).Text != string.Empty) && ((TextBox)(gvRoomBlock.Rows[i].FindControl("txtCBlock"))).Text != null)
								{
									if (CRoom.Contains("."))
										intCRoom = Convert.ToInt32(CRoom.Split('.')[0].ToString());
									else
										intCRoom = Convert.ToInt32(CRoom);
								}
								roompattern.New_RoomBlock = intCRoom;
								logger.Info("1420 roompattern.new_roomblock  " + roompattern.New_RoomBlock);

								logger.Info("UpdateRoomblockStatus   Method event Id:" + _eventID);
								string RoomGUID = gvRoomBlock.Rows[i].Cells[8].Text; //_eventID ...bug
								roompattern.New_roompatternId = new Guid(RoomGUID);

								// Update the RommPattern.                     
								logger.Info("1430 roompattern.new_percentofpeak = " + roompattern.New_PercentofPeak + "- roompattern.new_roomblock " + roompattern.New_RoomBlock);

								roompattern["bcmc_user"] = this.Username;
								_service.Update(roompattern);
							}

							String jsCode = BindPeakroom(gvRoomBlock, _eventID);
							string myscript = jsCode + "alert('Successfully updated ');";
							Page.ClientScript.RegisterStartupScript(this.GetType(), "myscript", myscript, true);

							RetrieveBasedonStatus(_service);
							btnlead.Enabled = true;
						}
					}
					else
					{
						DisplayNullDateRecords(entityCollection);
					}
				}
			}
			catch (System.Web.Services.Protocols.SoapException ex)
			{
				logger.Error(ex.Detail.InnerText, ex);
			}
			catch (Exception ex)
			{
				logger.Error("Dynamicgridview Page:  UpdateRoomblockStatus Method: Error" + ex.ToString());
			}
		}
#endregion //NewUpdateStatus Recomended solution

#region Original UpdateStatus
		private void UpdateRoomblockStatus(string _eventID, int Updatestatus)
		{
			try
			{
				if (gvFormLoad.Rows.Count > 0)
				{
					for (int i = 0; i < gvFormLoad.Rows.Count; i++)
					{
						// Create the RoomPattern object.
						New_roompattern roompattern = new New_roompattern();
						string RoomGUID = //gvFormLoad.Rows[i].Cells[7].Text; 
							dtretrieve.Rows[i]["RoomGUID"].ToString();
						roompattern.New_roompatternId = new Guid(RoomGUID);

						HiddenField txtcurrentpercent = (HiddenField)gvFormLoad.Rows[i].FindControl("hdnfdValue");
						string CPeak = txtcurrentpercent.Value;
						int intCPeak = 0;
						if ((((HiddenField)(gvFormLoad.Rows[i].FindControl("hdnfdValue"))).Value != string.Empty) && ((HiddenField)(gvFormLoad.Rows[i].FindControl("hdnfdValue"))) != null)
						{
							if (CPeak.Contains("."))
							{
								intCPeak = Convert.ToInt32(CPeak.Split('.')[0].ToString());
							}
							else
							{
								intCPeak = Convert.ToInt32(CPeak);
							}
						}
						roompattern.New_PercentofPeak = intCPeak;

						string CRoom = "0";
						int intCRoom = 0;
						if (gvFormLoad.Rows[i].Enabled == true)
						{
							TextBox txtcurrentroom = (TextBox)gvFormLoad.Rows[i].FindControl("txtCBlock");
							CRoom = txtcurrentroom.Text;
							if ((((TextBox)(gvFormLoad.Rows[i].FindControl("txtCBlock"))).Text != string.Empty) && ((TextBox)(gvFormLoad.Rows[i].FindControl("txtCBlock"))).Text != null)
							{
								if (CRoom.Contains("."))
								{
									intCRoom = Convert.ToInt32(CRoom.Split('.')[0].ToString());
								}
								else
								{
									intCRoom = Convert.ToInt32(CRoom);
								}
							}
							roompattern.New_RoomBlock = intCRoom;
						}
						else
						{
							//For Diasbled Records Current RoomBlock value set to zero  .
							intCRoom = 0;
							roompattern.New_RoomBlock = intCRoom;
						}

						int intdaynumber = i + 1;
						roompattern.New_DayNumber = intdaynumber;
						roompattern["bcmc_user"] = this.Username;
						_service.Update(roompattern);
					}

					String jsCode = BindPeakroom(gvFormLoad, _eventID);

					if (Updatestatus == 1)
					{
						string myscript = jsCode + "alert('Successfully updated ');";
						Page.ClientScript.RegisterStartupScript(this.GetType(), "myscript", myscript, true);
					}

					RetrieveBasedonStatus(_service);
					btnlead.Enabled = true;
				}
				else if (gvRoomBlock.Rows.Count > 0)
				{
					for (int i = 0; i < gvRoomBlock.Rows.Count; i++)
					{
						New_roompattern roompattern = new New_roompattern();
						string RoomGUID = gvRoomBlock.Rows[i].Cells[8].Text;
						logger.Info("UpdateRoomblockStatus Updating New_roompatternId=" + RoomGUID);
						roompattern.New_roompatternId = new Guid(RoomGUID);

						HiddenField txtcurrentpercent = (HiddenField)gvRoomBlock.Rows[i].FindControl("hdnfdValue");
						string CPeak = txtcurrentpercent.Value;

						int intCPeak = 0;
						if ((((HiddenField)(gvRoomBlock.Rows[i].FindControl("hdnfdValue"))).Value != string.Empty) && ((HiddenField)(gvRoomBlock.Rows[i].FindControl("hdnfdValue"))) != null)
						{
							if (CPeak.Contains("."))
							{
								intCPeak = Convert.ToInt32(CPeak.Split('.')[0].ToString());
							}
							else
							{
								intCPeak = Convert.ToInt32(CPeak);
							}
						}
						roompattern.New_PercentofPeak = intCPeak;

						TextBox txtcurrentroom = (TextBox)gvRoomBlock.Rows[i].FindControl("txtCBlock");
						string CRoom = txtcurrentroom.Text;
						int intCRoom = 0;
						if ((((TextBox)(gvRoomBlock.Rows[i].FindControl("txtCBlock"))).Text != string.Empty) && ((TextBox)(gvRoomBlock.Rows[i].FindControl("txtCBlock"))).Text != null)
						{
							if (CRoom.Contains("."))
							{
								intCRoom = Convert.ToInt32(CRoom.Split('.')[0].ToString());
							}
							else
							{
								intCRoom = Convert.ToInt32(CRoom);
							}
						}
						roompattern.New_RoomBlock = intCRoom;

						roompattern["bcmc_user"] = this.Username;
						_service.Update(roompattern);
                    }


					String jsCode = BindPeakroom(gvRoomBlock, _eventID);

					string myscript = jsCode + "alert('Successfully updated ');";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "myscript", myscript, true);

                    RetrieveBasedonStatus(_service);
                    btnlead.Enabled = true;
                }
            }
			catch (System.Web.Services.Protocols.SoapException ex)
			{
				logger.Error(ex.Detail.InnerText, ex);
			}
            catch (Exception ex)
            {
                logger.Error("UpdateRoomblockStatus" + ex.ToString());
            }
        }
#endregion //Original UpdateStatus

		private String BindPeakroom(GridView gvRoomBlock, string _eventID)
        {
			int _peakRoomNight = 0;
			int _totalRoomBlock = 0;
			try
            {
				for (int i = 0; i < gvRoomBlock.Rows.Count; i++)
                {
					int current_block = 0;
					TextBox txtboxCurrentRoomblock = (TextBox)gvRoomBlock.Rows[i].FindControl("txtCBlock");
					if (null != txtboxCurrentRoomblock.Text && txtboxCurrentRoomblock.Text != string.Empty)
						current_block = int.Parse(txtboxCurrentRoomblock.Text);

					_totalRoomBlock += current_block;

					if (current_block > _peakRoomNight)
						_peakRoomNight = current_block;
                }
				logger.InfoFormat("BindPeakRoom: TotalHotelRooms={0} Peak={1} Event={2}", 
					_totalRoomBlock, _peakRoomNight, _eventID);

				Opportunity Opportunity_ = new Opportunity();
				Opportunity_.OpportunityId = new Guid(_eventID);
				Opportunity_.New_HotelRoomNights = _totalRoomBlock;
				Opportunity_.New_PeakHotelRoomNights = _peakRoomNight;
				_service.Update(Opportunity_);
			}
			catch (System.Web.Services.Protocols.SoapException ex)
			{
				logger.Error(ex.Detail.InnerText, ex);
            }
            catch (Exception ex)
            {
                logger.Error("BindPeakroom " + ex.ToString());
            }

			// Build the JavaScript code to be used to update the CRM event form.
			return String.Format("updateParent({0}, {1}); ", 
							_totalRoomBlock, _peakRoomNight);
        }

        private void CheckEventUpdateStatus(OrganizationService _service, string getRecordid)
        {
            EntityCollection _businessEntitiesRP = AssignDayNumberRoomPattern(getRecordid, _service);
            New_roompattern entity = new New_roompattern();
            for (int i = 0; i < _businessEntitiesRP.Entities.Count; i++)
            {
				try
				{
					Entity rpEntity = _businessEntitiesRP.Entities[i];

					entity = (New_roompattern)rpEntity;
					entity.Bcmc_statustype = 0;
					entity["bcmc_user"] = this.Username;
					_service.Update(entity);
				}
				catch (Exception ex)
				{
					logger.Error(String.Format("Update RoomPattern Status {0}", entity.New_roompatternId), ex);
				}
            }
        }

        private EntityCollection AssignDayNumberRoomPattern(string eventGUID, OrganizationService _service)
        {
			EntityCollection _businessEntitiesRP = null;
			try
			{
				ConditionExpression conditionRP = new ConditionExpression();
				conditionRP.AttributeName = "new_eventid";
				conditionRP.Operator = ConditionOperator.Equal;
				conditionRP.Values.Add(eventGUID.ToString());

				FilterExpression filterRP = new FilterExpression();
				filterRP.FilterOperator = LogicalOperator.And;
				filterRP.Conditions.Add(conditionRP);

				OrderExpression orderExpr = new OrderExpression();
				orderExpr.AttributeName = "bcmc_date";
				orderExpr.OrderType = OrderType.Ascending;

				QueryExpression queryRP = new QueryExpression();
				queryRP.EntityName = "new_roompattern";
				queryRP.ColumnSet = new ColumnSet(true);
				queryRP.Criteria = filterRP;
				queryRP.Orders.Add(orderExpr);

				_businessEntitiesRP = _service.RetrieveMultiple(queryRP);
			}
			catch (Exception ex)
			{
				logger.Error("AssignDayNumberRoomPattern", ex);
			}

            return _businessEntitiesRP;
        }

		/// <summary>
		/// Display an alert box when the page completes posting back.
		/// </summary>
		/// <param name="message"></param>
		protected void Alert(String message)
		{
			logger.InfoFormat("Enter Alert({0})", message);
			string myscript = String.Format("alert('{0}');", message);
			Page.ClientScript.RegisterStartupScript(this.GetType(), "myscript", myscript, true);
		}
//#endregion //UserdefinedMethods
	}
}