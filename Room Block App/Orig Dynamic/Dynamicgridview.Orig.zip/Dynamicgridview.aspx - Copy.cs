﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;

using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

using System.Collections.Generic;
using System.Text;
using System.Net;
using log4net;
using Microsoft.Xrm.Client.Services;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Data.Services.Common;
#if true
using Xrm; //XrmEarlyBinding;


namespace RoomBlock
{
    public partial class Dynamicgridview : System.Web.UI.Page
    {
#if true
#region "Variable Declaration"
		private static ILog logger = LogManager.GetLogger(typeof(Dynamicgridview));
		static OrganizationService _service; //ytodo remove = CrmServiceManager.GetCrmService();
        static DataTable dtretrieve = new DataTable();
        static DataTable dtRoomBlock = new DataTable();
        static string getEventStatus = string.Empty;
		int _totalRoomBlock = 0;
		int _peakRoomNight = 0;
        //ytodo remove string PeakRoomNight = string.Empty;
        //static string _eventID = string.Empty;
#endregion
#endif

#region Pageload

        protected void Page_Load(object sender, EventArgs e)
        {
#if true
            if (!IsPostBack)
            {
                bool rpStatusFlag = false;
                string getRecordid = string.Empty;
                try
                {
					log4net.Config.XmlConfigurator.Configure();
					logger.Info("10 Dynamicgridview Page: Page_Load Method: Started");

					_service = CrmServiceManager.GetCrmService();
                    if (HttpContext.Current.Request.QueryString["status"] == null)
                    {
                        if (HttpContext.Current.Request.QueryString["recordid"] != null)
                        {
                            getRecordid = Request.QueryString["recordid"].ToString();
                            ViewState["_eventID"] = getRecordid;
                            if (HttpContext.Current.Request.QueryString["rpStatus"] != null)
                            {
                                rpStatusFlag = true;
                                CheckEventUpdateStatus(_service, getRecordid);
                            }
                            else
                                rpStatusFlag = false;

                            getEventStatus = "";
                            getEventStatus = CheckEventStatus(_service, getRecordid);

							logger.Info("20 Dynamicgridview Page: Page_Load Method: getEventStatus = " + getEventStatus);

                            if (getEventStatus != string.Empty && getEventStatus == "10")
                            {
                                RetrieveBasedonStatus(_service);
                                btnsave.Text = "Update";
                                btnlead.Enabled = true;
                            }
                            else
                                Retrieve(_service, rpStatusFlag,0);

							logger.Info("30 Dynamicgridview Page: Page_Load Method: End");
                        }
                        else
                        {
                            btnsave.Visible = false;
                            btnlead.Visible = false;
                        }
                    }
                    else
                    {
                        Retrieve(_service, true,1);
                        btnsave.Text = "Save";
                        btnlead.Enabled = false;
                    }
                }
				catch (System.Web.Services.Protocols.SoapException ex)
				{
					logger.Error(ex.Detail.InnerText, ex);
				}
                catch (Exception ex)
                {
					logger.Error("Dynamicgridview Page: Page_Load()", ex);
                }
                finally
                {

					logger.Info("40 Dynamicgridview Page:  PageLoad Method: Before service execution");
                    string _eventID = Convert.ToString(ViewState["_eventID"]);
                    if (_eventID != null && _eventID != string.Empty)
                    {
                        EntityCollection entityCollection = CheckRoomPatternecords(_eventID, _service);

						logger.Info("50 Dynamicgridview Page:  PageLoad Method: After service execution");
						logger.Info("60 Dynamicgridview Page: entityCollection.Entities.Length:: " + entityCollection.Entities.Count);

						if (entityCollection.Entities.Count > 0 && ViewState["DisplayDateisNULL"] == null)
                        {
                            btnsave.Text = "Update";
                            btnlead.Enabled = true;
                        }
                        else if (ViewState["DisplayDateisNULL"] != null)
                        {
                            btnsave.Enabled = false;
                            btnlead.Enabled = false;
                        }
                        else
                        {
                            btnsave.Text = "Save";
                            btnlead.Enabled = false;
                            UpdatePeakRoomNights(_eventID);
                        }
                    }
                }
            }
#endif
        }
		#endregion
#if true

#region Events
        private void UpdatePeakRoomNights(string _eventID)
        {
            try
            {
				//logger.Info("70 Dynamicgridview Page: UpdatePeakRoomNights : Started");
				logger.Info("70 Dynamicgridview Page:  UpdatePeakRoomNights Method: Before service execution");

                Entity entity = new Entity("new_roompattern");
                EntityCollection entityCollection = CheckRoomPatternecords(_eventID, _service);

                //logger.Info("Dynamicgridview Page:  UpdatePeakRoomNights Method: After service execution");
                logger.Info("80 Dynamicgridview Page: entityCollection.BusinessEntities.Length:: " + entityCollection.Entities.Count);

                if (entityCollection.Entities.Count == 0)
                {
                    Entity oppEvent = new Entity("opportunity");
                    oppEvent["new_hotelroomnights"] = 0;
                    oppEvent["new_peakhotelroomnights"] = 0;
                    oppEvent["opportunityid"] = new Guid(_eventID);
                    _service.Update(oppEvent);
                }
				logger.Info("90 Dynamicgridview Page: UpdatePeakRoomNights : Ended NS00: " + _eventID);
            }
			catch (System.Web.Services.Protocols.SoapException ex)
			{
				logger.Error(ex.Detail.InnerText, ex);
			}
            catch (Exception ex)
            {
				logger.Error("Dynamicgridview Page: UpdatePeakRoomNights()", ex);
            }
        }

        protected void btnlead_Click(object sender, EventArgs e)
        {
			//if (!ValidateProposedDates())
			//	return;
            SendLeadtoHotel();
        }

        private void SendLeadtoHotel()
        {
            try
            {
                string _eventID = Convert.ToString(ViewState["_eventID"]);

				logger.Info("100 Dynamicgridview Page:  SendLeadtoHotel Method: Started");

                if (gvFormLoad.Rows.Count > 0)
                {
                    if (getEventStatus != "10")
                        UpdateRoomblock(_eventID,0);
                    else
                        UpdateRoomblockStatus(_eventID,0);

                    foreach (GridViewRow Item in gvFormLoad.Rows)
                    {
                        TextBox txtcurrent = (TextBox)Item.FindControl("txtCBlock");
                        string currentroom = txtcurrent.Text;

						System.Web.UI.WebControls.
                        Label txtoriginal = (System.Web.UI.WebControls.Label)Item.FindControl("lblOblock");
                        txtoriginal.Text = currentroom;

                        HiddenField txt1 = (HiddenField)Item.FindControl("hdnfdValue");
                        string current = txt1.Value;
						System.Web.UI.WebControls.
                        Label txt2 = (System.Web.UI.WebControls.Label)Item.FindControl("lblOPeak");
                        txt2.Text = current;
                    }

                    for (int i = 0; i < gvFormLoad.Rows.Count; i++)
                    {
                        // Create the contact object.
                        Entity roompattern = new Entity("new_roompattern");

                        // Set the contact object properties to be updated.
						System.Web.UI.WebControls.
                        Label txtOriginalpeak = (System.Web.UI.WebControls.Label)gvFormLoad.Rows[i].FindControl("lblOPeak");
                        string OriginalPeak = txtOriginalpeak.Text;
                        int intOPeak = 0;

                        if ((((System.Web.UI.WebControls.Label)
								(gvFormLoad.Rows[i].FindControl("lblOPeak"))).Text != string.Empty) 
							&& ((System.Web.UI.WebControls.Label)
								(gvFormLoad.Rows[i].FindControl("lblOPeak"))).Text != null)
                        {
                            if (OriginalPeak.Contains("."))
                            {
                                intOPeak = Convert.ToInt32(OriginalPeak.Split('.')[0].ToString());
                            }
                            else
                            {
                                intOPeak = Convert.ToInt32(OriginalPeak);
                            }
                        }
                        else
                        {
                            intOPeak = 0;
                        }
                        roompattern["bcmc_originalpercentofpeak"] = intOPeak;

                        HiddenField txtCurrentpeak = (HiddenField)gvFormLoad.Rows[i].FindControl("hdnfdValue");
                        string CurrentPeak = txtCurrentpeak.Value;
                        int intCPeak = 0;

                        if ((((HiddenField)(gvFormLoad.Rows[i].FindControl("hdnfdValue"))).Value != string.Empty) 
							&& ((HiddenField)(gvFormLoad.Rows[i].FindControl("hdnfdValue"))) != null)
                        {
                            if (CurrentPeak.Contains("."))
                            {
                                intCPeak = Convert.ToInt32(CurrentPeak.Split('.')[0].ToString());
                            }
                            else
                            {
                                intCPeak = Convert.ToInt32(CurrentPeak);
                            }
                        }
                        else
                        {
                            intCPeak = 0;
                        }

                        roompattern["new_percentofpeak"] = intCPeak;


                        //logger.Info("------------------------------------Dynamicgridview Page:  SendLeadtoHotel Method------------------------------------------------");
                        logger.Info("roompattern.bcmc_originalpercentofpeak  = " + 
							((int?)roompattern["bcmc_originalpercentofpeak"]).ToString() + 
							"- roompattern.new_percentofpeak " + 
							(roompattern["new_percentofpeak"] as int?).ToString());
                        //logger.Info("-----------------------------------Dynamicgridview Page:  SendLeadtoHotel Method-------------------------------------------------------");

						System.Web.UI.WebControls.
                        Label txtOriginalblock = (System.Web.UI.WebControls.Label)
							gvFormLoad.Rows[i].FindControl("lblOblock");
                        string Originalblock = txtOriginalblock.Text;
                        int intOBlock = 0;

                        if ((((System.Web.UI.WebControls.Label)
								(gvFormLoad.Rows[i].FindControl("lblOblock"))).Text != string.Empty) 
							&& ((System.Web.UI.WebControls.Label)
								(gvFormLoad.Rows[i].FindControl("lblOblock"))).Text != null)
                        {
                            if (Originalblock.Contains("."))
                            {
                                intOBlock = Convert.ToInt32(Originalblock.Split('.')[0].ToString());
                            }
                            else
                            {
                                intOBlock = Convert.ToInt32(Originalblock);
                            }
                        }
                        else
                        {
                            intOBlock = 0;
                        }
                        roompattern["bcmc_originalroomblock"] = intOBlock;

                        TextBox txtcurrentblock = (TextBox)gvFormLoad.Rows[i].FindControl("txtCBlock");
                        string Currentblock = txtcurrentblock.Text;
                        int intCBlock = 0;
                        if ((((TextBox)(gvFormLoad.Rows[i].FindControl("txtCBlock"))).Text != string.Empty) 
							&& ((TextBox)(gvFormLoad.Rows[i].FindControl("txtCBlock"))).Text != null)
                        {
                            if (Currentblock.Contains("."))
                            {
                                intCBlock = Convert.ToInt32(Currentblock.Split('.')[0].ToString());
                            }
                            else
                            {
                                intCBlock = Convert.ToInt32(Currentblock);
                            }
                        }
                        else
                        {
                            intCBlock = 0;
                        }
                        roompattern["new_roomblock"] = intCBlock;

						//logger.Info("-----------------------------------------Dynamicgridview Page:  SendLeadtoHotel Method----------------------------------------------");
						logger.Info("120 roompattern.bcmc_originalroomblock   = " + 
							(roompattern["bcmc_originalroomblock"] as int?).ToString() + 
							"-  roompattern.new_roomblock " + 
							(roompattern["new_roomblock"] as int?).ToString());
						//logger.Info("-----------------------------------------Dynamicgridview Page:  SendLeadtoHotel Method---------------------------------------------------");

                        // The contactid is a key that references the ID of the contact to be updated.
                        roompattern["new_roompatternid"] = new Guid(dtretrieve.Rows[i]["RoomGUID"].ToString());

                        // Update the contact.
                        _service.Update(roompattern);

                        logger.Info("Dynamicgridview Page:  SendLeadtoHotel Method:Completed Successfully");
                    }

                    string myscript = "alert('Successfully completed.');";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "myscript", myscript, true);
                    btnlead.Enabled = true;
                }
                else if (gvRoomBlock.Rows.Count > 0)
                {
                    if (getEventStatus != "10")
                        UpdateRoomblock(_eventID,0);
                    else
                        UpdateRoomblockStatus(_eventID,0);

                    foreach (GridViewRow Item in gvRoomBlock.Rows)
                    {
                        TextBox txtcurrent = (TextBox)Item.FindControl("txtCBlock");
                        string currentroom = txtcurrent.Text;

						System.Web.UI.WebControls.
                        Label txtoriginal = (System.Web.UI.WebControls.Label)Item.FindControl("lblOblock");
                        txtoriginal.Text = currentroom;

                        HiddenField txt1 = (HiddenField)Item.FindControl("hdnfdValue");
                        string current = txt1.Value;
						System.Web.UI.WebControls.
                        Label txt2 = (System.Web.UI.WebControls.Label)Item.FindControl("lblOPeak");
                        txt2.Text = current;
                    }


                    for (int i = 0; i < gvRoomBlock.Rows.Count; i++)
                    {
                        // Create the contact object.
                        Entity roompattern = new Entity("new_roompattern");

						System.Web.UI.WebControls.
                        Label txtOriginalpeak = (System.Web.UI.WebControls.Label)gvRoomBlock.Rows[i].FindControl("lblOPeak");
                        string OriginalPeak = txtOriginalpeak.Text;
                        int intOPeak = Convert.ToInt32(OriginalPeak);

                        if ((((System.Web.UI.WebControls.Label)
							(gvRoomBlock.Rows[i].FindControl("lblOPeak"))).Text != string.Empty) 
							&& ((System.Web.UI.WebControls.Label)
							(gvRoomBlock.Rows[i].FindControl("lblOPeak"))).Text != null)
                        {
                            if (OriginalPeak.Contains("."))
                            {
                                intOPeak = Convert.ToInt32(OriginalPeak.Split('.')[0].ToString());
                            }
                            else
                            {
                                intOPeak = Convert.ToInt32(OriginalPeak);
                            }
                        }
                        else
                        {
                            intOPeak = 0;
                        }
                        roompattern["bcmc_originalpercentofpeak"] = intOPeak;

                        HiddenField txtCurrentpeak = (HiddenField)gvRoomBlock.Rows[i].FindControl("hdnfdValue");
                        string CurrentPeak = txtCurrentpeak.Value;
                        int intCPeak = 0;
                        if ((((HiddenField)(gvRoomBlock.Rows[i].FindControl("hdnfdValue"))).Value != string.Empty) 
							&& ((HiddenField)(gvRoomBlock.Rows[i].FindControl("hdnfdValue"))) != null)
                        {
                            if (CurrentPeak.Contains("."))
                            {
                                intCPeak = Convert.ToInt32(CurrentPeak.Split('.')[0].ToString());
                            }
                            else
                            {
                                intCPeak = Convert.ToInt32(CurrentPeak);
                            }
                        }
                        else
                        {
                            intCPeak = 0;
                        }
                        roompattern["new_percentofpeak"] = intCPeak;

						//logger.Info("---------------------------------------------------Dynamicgridview Page:  SendLeadtoHotel Method----------------------------------------------------------");
						logger.Info("130 roompattern.bcmc_originalpercentofpeak     = " +
							(roompattern["bcmc_originalpercentofpeak"] as int?).ToString() + 
							"-    roompattern.new_percentofpeak  " +
							(roompattern["new_percentofpeak"] as int?).ToString());
						//logger.Info("---------------------------------------------------Dynamicgridview Page:  SendLeadtoHotel Method----------------------------------------");

						System.Web.UI.WebControls.
                        Label txtOriginalblock = (System.Web.UI.WebControls.Label)gvRoomBlock.Rows[i].FindControl("lblOblock");
                        string Originalblock = txtOriginalblock.Text;

                        int intOBlock = 0;

                        if ((((System.Web.UI.WebControls.Label)(gvRoomBlock.Rows[i].FindControl("lblOblock"))).Text != string.Empty) 
							&& ((System.Web.UI.WebControls.Label)(gvRoomBlock.Rows[i].FindControl("lblOblock"))).Text != null)
                        {
                            if (Originalblock.Contains("."))
                            {
                                intOBlock = Convert.ToInt32(Originalblock.Split('.')[0].ToString());
                            }
                            else
                            {
                                intOBlock = Convert.ToInt32(Originalblock);
                            }
                        }
                        else
                        {
                            intOBlock = 0;
                        }
                        roompattern["bcmc_originalroomblock"] = intOBlock;

                        TextBox txtcurrentblock = (TextBox)gvRoomBlock.Rows[i].FindControl("txtCBlock");
                        string Currentblock = txtcurrentblock.Text;
                        int intCBlock = 0;
                        if ((((TextBox)(gvRoomBlock.Rows[i].FindControl("txtCBlock"))).Text != string.Empty) && ((TextBox)(gvRoomBlock.Rows[i].FindControl("txtCBlock"))).Text != null)
                        {
                            if (Currentblock.Contains("."))
                            {
                                intCBlock = Convert.ToInt32(Currentblock.Split('.')[0].ToString());
                            }
                            else
                            {
                                intCBlock = Convert.ToInt32(Currentblock);
                            }
                        }
                        else
                        {
                            intCBlock = 0;
                        }
                        roompattern["new_roomblock"] = intCBlock;

						//logger.Info("--------------------------------------------Dynamicgridview Page:  SendLeadtoHotel Method------------------------------------------------");
						logger.Info("140 roompattern.bcmc_originalroomblock    = " + 
							(roompattern["bcmc_originalroomblock"] as int?).ToString() + 
							"-   roompattern.new_roomblock  " + 
							(roompattern["new_roomblock"] as int?).ToString());
						//logger.Info("---------------------------------------------Dynamicgridview Page:  SendLeadtoHotel Method-------------------------------------------------");



                        // The contactid is a key that references the ID of the contact to be updated.
                        roompattern["new_roompatternid"] = new Guid(dtretrieve.Rows[i]["RoomGUID"].ToString());

                        // Update the contact.
						logger.Info("150 Dynamicgridview Page:  SendLeadtoHotel Method: Updating the record roompattern.new_roompatternid.Value " + gvRoomBlock.Rows[i].Cells[8].Text);
                        // Update the contact.
                        _service.Update(roompattern);

						logger.Info("160 Dynamicgridview Page:  SendLeadtoHotel Method: Completed Successfully");
                    }
                    string myscript = "alert('Successfully completed. ');";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "myscript", myscript, true);
                    btnlead.Enabled = false;

                }

                logger.Info("Dynamicgridview Page: SendLeadtoHotel : End");
            }
			catch (System.Web.Services.Protocols.SoapException ex)
			{
				logger.Error(ex.Detail.InnerText, ex);
			}
            catch (Exception ex)
            {
				logger.Error("Dynamicgridview Page: SendLeadtoHotel()", ex);
            }
        }

        protected void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
				logger.Info("170 Dynamicgridview Page: SaveClick : Started");

                string _eventID = Convert.ToString(ViewState["_eventID"]);

				logger.Info("180 Dynamicgridview Page: Save Method : _eventID:" + _eventID);
                if (btnsave.Text == "Save")
                {
                    BindSave(_eventID);
                }
                else if (btnsave.Text == "Update")
                {
                    if (getEventStatus != "10")
                        UpdateRoomblock(_eventID, 1);
                    else
                        UpdateRoomblockStatus(_eventID, 1);
                }
				logger.Info("190 Dynamicgridview Page: SaveClick : End");
            }
			catch (System.Web.Services.Protocols.SoapException ex)
			{
				logger.Error(ex.Detail.InnerText, ex);
			}
            catch (Exception ex)
            {
				logger.Error("Dynamicgridview Page: SaveClick", ex);
            }
        }

        protected void gvFormLoad_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            foreach (TableCell cell in e.Row.Cells)
            {
                if (e.Row.RowIndex >= 0)
                {
                    cell.Attributes["Style"] = "border-color:Gray;padding-left:8px;";
                }
            }

			// Add any holidays to the day or week.
			if (e.Row.RowType == DataControlRowType.DataRow)
			{
				DateTime dt = DateTime.Parse(e.Row.Cells[2].Text);
				String holiday = HelperFunctions.getHoliday(dt, _service, Cache);
				if (String.IsNullOrEmpty(holiday))
					return;

				e.Row.Cells[1].Text += "<br/>(" + holiday + ")";
				e.Row.Cells[1].Attributes["Style"] = "background-color:LightYellow;";
				logger.InfoFormat("gvFormLoad_RowDataBound() - {0} - {1}", e.Row.Cells[1].Text, e.Row.Cells[2].Text);
			}
        }

		#endregion

#region UserdefinedMethods

        private void Retrieve(OrganizationService _service, bool rpFlag,int onChangeStatus)
        {
            try
            {
				logger.Info("250 Dynamicgridview Page:  Retrieve Roomblock  Method: Started");
				if (HttpContext.Current.Request.QueryString["recordid"] == null)
                {
					btnsave.Visible = false;
					btnlead.Visible = false;
					return;
				}

                string getRecordid = Request.QueryString["recordid"].ToString();
                string _eventID = getRecordid.Replace("{", "").Replace("}", "");
				ViewState["_eventID"] = _eventID;

				// Get the dates from the event.
				var cols = new ColumnSet(new String[] { "new_arrivaldate", "new_departuredate" });
				var evt = (Opportunity)_service.Retrieve("opportunity", new Guid(_eventID), cols);
				DateTime dtArrivalDate = evt.New_arrivaldate ?? DateTime.MinValue;
				DateTime dtdeparture = evt.New_departuredate ?? DateTime.MinValue;

                try
                {
                    logger.Info("Dynamicgridview Page:  Retrieve Roomblock  Method: Started");
                    // Define the entity attributes (database table columns) that are to be retrieved.

                    New_roompattern entity = new New_roompattern();

                    EntityCollection entityCollection = CheckRoomPatternecords(_eventID, _service);
                    logger.Info("Dynamicgridview Page:  Retrieve Roomblock  Method: After service execution");
                    Hashtable hshTableRoomPattern = new Hashtable();
                    if (entityCollection.Entities.Count > 0)
                    {
					logger.Info("260 Dynamicgridview Page: entityCollection.BusinessEntities.Length:: " + 
							entityCollection.Entities.Count);

                        for (int j = 0; j < entityCollection.Entities.Count; j++)
                        {
                            entity = (New_roompattern)entityCollection.Entities[j];
							logger.Info("270 Dynamicgridview Page:  Retrieve Roomblock  Method: Retrieve Rooom Pattern Entity Value " + entity);

                            //Added by ZSL Team on 28-06-2012
                            if (entity["bcmc_date"] != null)
                                hshTableRoomPattern.Add("bcmc_date" + j, (entity["bcmc_date"] as DateTime?).Value.ToShortDateString());
                            else
                                hshTableRoomPattern.Add("bcmc_date" + j, "01/01/0001");

                        }
                        DataRow drretrieve = dtretrieve.NewRow();

                        //Add By ZSL Team 28/05/2012
                        if (hshTableRoomPattern.Count > 0)
                        {
                            string tempArrivalDateRoomPattern = hshTableRoomPattern["bcmc_date0"].ToString();
                              
                            if (tempArrivalDateRoomPattern != "01/01/0001")
                            {
								logger.Info("280 Dynamicgridview Page:  Retrieve Roomblock  Method: Retrieve Rooom Pattern ArrivalDate " +
										hshTableRoomPattern["bcmc_date0"].ToString());
								string tempDepartureDateRoomPattern = hshTableRoomPattern["bcmc_date" + (hshTableRoomPattern.Count - 1).ToString()].ToString();
								logger.Info("290 Dynamicgridview Page:  Retrieve Roomblock  Method: Retrieve Rooom Pattern ArrivalDate " +
										tempDepartureDateRoomPattern);

#region Bind Grid
                                dtdeparture = dtdeparture.AddDays(-1);
                                string _Departuredate = Convert.ToString(dtdeparture.ToShortDateString());
                                DateTime dtTempDepTime = Convert.ToDateTime(tempDepartureDateRoomPattern);
                                DateTime dtDeparturedate = Convert.ToDateTime(_Departuredate);
                                DateTime dtTempArrTime = Convert.ToDateTime(tempArrivalDateRoomPattern);

                                logger.Info("Arrival Date Check dtArrivalDate: + " + dtArrivalDate.ToString());
                                logger.Info("Arrival Date Check dtTempArrTime: + " + dtTempArrTime.ToString());

                                int getArrResult = dtTempArrTime.CompareTo(dtArrivalDate);
                                int getDepResult = dtTempDepTime.CompareTo(dtDeparturedate);

                                if (getArrResult == 0)
                                {
                                    if (getDepResult == 0)
                                    {
                                        dtretrieve = new DataTable();
                                        dtretrieve.Columns.Add("DayNumber");
                                        dtretrieve.Columns.Add("DayofWeek");
                                        dtretrieve.Columns.Add("Date");
                                        dtretrieve.Columns.Add("Original % of Peak");
                                        dtretrieve.Columns.Add("Original Block");
                                        dtretrieve.Columns.Add("Current % of Peak");
                                        dtretrieve.Columns.Add("Current Block");
                                        dtretrieve.Columns.Add("RoomGUID");
                                        for (int i = 0; i < entityCollection.Entities.Count; i++)
                                        {
                                            logger.Info("Dynamicgridview Page: entityCollection.BusinessEntities.Length:: " + entityCollection.Entities.Count);
                                            DataRow drretrieves = dtretrieve.NewRow();

                                            logger.Info("Dynamicgridview Page:  Retrieve Roomblock  Method: Retrieve Rooom Pattern Entity Name " + entity);
                                            entity = (New_roompattern)entityCollection.Entities[i];

                                            drretrieves["RoomGUID"] = (entity["new_roompatternid"] as Guid?).Value.ToString();
                                            logger.Info("Dynamicgridview Page:  Retrieve Roomblock  Method: Retrieve Rooom Pattern Entity - entity new_roompatternid Value.ToString() " + (entity["new_roompatternid"] as Guid?).Value.ToString());

                                            if (entity["new_daynumber"] != null)
                                                if (entity["new_daynumber"] != null)
                                                {
                                                    drretrieves["DayNumber"] = entity["new_daynumber"] as string;
                                                }
                                                else
                                                {
                                                    drretrieves["DayNumber"] = "0";
                                                }
                                            if (entity["new_name"] != null)
                                            {
                                                drretrieves["DayofWeek"] = entity["new_name"];
                                            }
                                            if (entity["bcmc_date"] != null)
                                            {
                                                drretrieves["Date"] = (entity["bcmc_date"] as DateTime?).Value.ToShortDateString();
                                            }
                                            if (entity["bcmc_originalpercentofpeak"] != null)
                                            {
                                                drretrieves["Original % of Peak"] = entity.Bcmc_OriginalpercentofPeak;
												logger.Info("Dynamicgridview Page:  Retrieve Roomblock  Method: entity.bcmc_originalpercentofpeak.Value  " + entity.Bcmc_OriginalpercentofPeak);
                                            }
											else
												logger.Info("Dynamicgridview Page:  Retrieve Roomblock  Method: entity.bcmc_originalpercentofpeak.Value -null ");

                                            if (entity.New_PercentofPeak != null)
                                                //if (!entity.New_PercentofPeak.Value.IsNull)
                                                {
                                                    drretrieves["Current % of Peak"] = entity.New_PercentofPeak.Value;
												logger.Info("Dynamicgridview Page:  Retrieve Roomblock  Method: entity.new_percentofpeak.Value  " + entity.New_PercentofPeak.Value);
                                                }
											else
												logger.Info("Dynamicgridview Page:  Retrieve Roomblock  Method: entity.new_percentofpeak.Value - null ");


                                            if (entity.Bcmc_OriginalRoomBlock != null)
                                                //if (!entity.Bcmc_OriginalRoomBlock.IsNull)
                                                {
                                                    drretrieves["Original Block"] = entity.Bcmc_OriginalRoomBlock.Value;
												logger.Info("Dynamicgridview Page:  Retrieve Roomblock  Method: entity.bcmc_originalroomblock.Value  " + entity.Bcmc_OriginalRoomBlock.Value);
                                                }
											else
												logger.Info("Dynamicgridview Page:  Retrieve Roomblock  Method: entity.bcmc_originalroomblock.Value - null ");
                                            if (entity.New_RoomBlock != null)
                                                //if (!entity.New_RoomBlock.IsNull)
                                                {
                                                    drretrieves["Current Block"] = entity.New_RoomBlock.Value;
												logger.Info("Dynamicgridview Page:  Retrieve Roomblock  Method: entity.new_roomblock.Value  " + entity.New_RoomBlock.Value);
                                                }
											else
												logger.Info("Dynamicgridview Page:  Retrieve Roomblock  Method: entity.new_roomblock.Value  - null ");
                                            dtretrieve.Rows.Add(drretrieves);
                                        } 
                                        gvFormLoad.DataSource = dtretrieve;
                                        gvFormLoad.DataBind();
                                        gvFormLoad.Columns[7].Visible = false;
                                        gvFormLoad.Columns[0].Visible = false;
                                        gvFormLoad.Visible = true;
                                        if (gvFormLoad.Rows.Count > 0)
                                        {
                                            DataTable dt = new DataTable();
                                            gvRoomBlock.DataSource = dt;
                                            gvRoomBlock.DataBind();
                                            gvRoomBlock.Visible = false;
                                        }
                                        btnsave.Text = "Update";
                                        btnlead.Enabled = true;
                                    }
                                    else
                                    {
                                        if (onChangeStatus==1)
                                            DeleteRoomblock(_eventID);
                                        RoomBlockGrid();
                                    }
                                }
                                else
                                {
                                    if (onChangeStatus == 1)
                                        DeleteRoomblock(_eventID);
                                    RoomBlockGrid();
                                }
		#endregion
                            }
                            else
                            {
                                DisplayNullDateRecords(entityCollection);
                            }
                        }
                    }
                    else
                    {
                        RoomBlockGrid();
                    }

					logger.Info("300 Dynamicgridview Page:Retrieve Roomblock Method: End");
                }
				catch (System.Web.Services.Protocols.SoapException ex)
				{
					logger.Error(ex.Detail.InnerText, ex);
				}
                catch (Exception ex)
                {
                    logger.Error("Dynamicgridview Page: Retrieve Roomblock  Method: Error" + ex.ToString());
                }
            }
			catch (System.Web.Services.Protocols.SoapException ex)
            {
				logger.Error(ex.Detail.InnerText, ex);
            }
            catch (Exception ex)
            {
                logger.Error("Dynamicgridview Page: Retrieve Roomblock  Method: Error" + ex.ToString());
			}
			finally
			{
				logger.Info("310 Dynamicgridview Page:Retrieve Roomblock Method: End");
            }
        }

        private void DisplayNullDateRecords(EntityCollection entityCollection)
        {
            try
            {
				logger.Info("320 Dynamicgridview Page:DisplayNullDateRecords  Method: Started");
                New_roompattern entity = new New_roompattern();
                DataTable dtretrieve = new DataTable();
                dtretrieve.Columns.Add("DayNumber");
                dtretrieve.Columns.Add("DayofWeek");
                dtretrieve.Columns.Add("Date");
                dtretrieve.Columns.Add("Original % of Peak");
                dtretrieve.Columns.Add("Original Block");
                dtretrieve.Columns.Add("Current % of Peak");
                dtretrieve.Columns.Add("Current Block");
                dtretrieve.Columns.Add("RoomGUID");
                for (int i = 0; i < entityCollection.Entities.Count; i++)
                {
					logger.Info("330 Dynamicgridview Page: entityCollection.BusinessEntities.Length:: " + entityCollection.Entities.Count);
                    DataRow drretrieves = dtretrieve.NewRow();

					logger.Info("340 Dynamicgridview Page:  DisplayNullDateRecords Method: Retrieve Rooom Pattern Entity Name " + entity);
                    entity = (New_roompattern)entityCollection.Entities[i];

                    drretrieves["RoomGUID"] = entity.New_roompatternId.Value.ToString();
					logger.Info("350 Dynamicgridview Page: DisplayNullDateRecords Method: Retrieve Rooom Pattern Entity - entity new_roompatternid Value.ToString() " + entity.New_roompatternId.Value.ToString());

                    if (entity.New_DayNumber != null)
                        //if (!entity.New_DayNumber.IsNull)
                        {
                            drretrieves["DayNumber"] = entity.New_DayNumber.Value;
                        }
                        else
                        {
                            drretrieves["DayNumber"] = "0";
                        }
                    if (entity.New_name != null)
                    {
                        drretrieves["DayofWeek"] = entity.New_name;
                    }
                    if (entity.Bcmc_Date != null)
                        //if (!entity.Bcmc_Date.IsNull)
                        {
                            drretrieves["Date"] = entity.Bcmc_Date.Value.ToShortDateString();
                        }
                    if (entity.Bcmc_OriginalpercentofPeak != null)
                        //if (!entity.Bcmc_OriginalpercentofPeak.IsNull)
                        {
                            drretrieves["Original % of Peak"] = entity.Bcmc_OriginalpercentofPeak.Value;
                        }
                    if (entity.New_PercentofPeak != null)
                        //if (!entity.New_PercentofPeak.IsNull)
                        {
                            drretrieves["Current % of Peak"] = entity.New_PercentofPeak.Value;
                        }

                    if (entity.Bcmc_OriginalRoomBlock != null)
                        //if (!entity.bcmc_originalroomblock.IsNull)
                        {
                            drretrieves["Original Block"] = entity.Bcmc_OriginalRoomBlock.Value;
                        }
                    if (entity.New_RoomBlock != null)
                        //if (!entity.New_RoomBlock.IsNull)
                        {
                            drretrieves["Current Block"] = entity.New_RoomBlock.Value;
                        }
                    dtretrieve.Rows.Add(drretrieves);

                }
                gvFormLoad.DataSource = dtretrieve;
                gvFormLoad.DataBind();
                gvFormLoad.Columns[7].Visible = false;
                gvFormLoad.Columns[0].Visible = false;
                gvFormLoad.Visible = true;
                if (gvFormLoad.Rows.Count > 0)
                {
                    DataTable dt = new DataTable();
                    gvRoomBlock.DataSource = dt;
                    gvRoomBlock.DataBind();
                    gvRoomBlock.Visible = false;
                }


                ViewState["DisplayDateisNULL"] = "DisplayDateisNULL";
				logger.Info("360 Dynamicgridview Page:DisplayNullDateRecords Method: End");
            }
			catch (System.Web.Services.Protocols.SoapException ex)
			{
				logger.Error(ex.Detail.InnerText, ex);
			}
            catch (Exception ex)
            {

                logger.Error("Dynamicgridview Page: DisplayNullDateRecords  Method: Error" + ex.ToString()); 
            }             
          
        }

        private void DeleteRoomblock(string eventid)
        {
            try
            {
				logger.Info("370 Dynamicgridview Page:   DeleteRoomblock Method: Started");
                string Eventid = eventid;

                ColumnSet columnSet = new ColumnSet(new string[] { "new_roompatternid" });
                // Create a retrieve request object.
                ConditionExpression condition = new ConditionExpression();

                condition.AttributeName = "new_eventid";

                condition.Operator = ConditionOperator.Equal;

                condition.Values.Add(Eventid);

				logger.Info("380 Dynamicgridview Page:   DeleteRoomblock Method: new_eventid = " + Eventid);


                FilterExpression filter = new FilterExpression();
                filter.Conditions.Add(condition);
                // Create the query.
                QueryExpression query = new QueryExpression();

                // Set the properties of the query.
                query.ColumnSet = columnSet;

                query.Criteria = filter;

                query.EntityName = New_roompattern.EntityLogicalName;


                EntityCollection entityCollection = _service.RetrieveMultiple(query);

                if (entityCollection.Entities.Count > 0)
                {
					logger.Info("390 Dynamicgridview Page:   DeleteRoomblock Method: Retrieve records count " + entityCollection.Entities.Count);

                    for (int j = 0; j < entityCollection.Entities.Count; j++)
                    {
                        New_roompattern entity = (New_roompattern)entityCollection.Entities[j];

                        if (entity != null)
                        {
							logger.Info("400 Dynamicgridview Page:   DeleteRoomblock Method: Deleting record " + entity.New_roompatternId.Value.ToString());

							_service.Delete(New_roompattern.EntityLogicalName, new Guid(entity.New_roompatternId.Value.ToString()));

							logger.Info("410 Dynamicgridview Page:   DeleteRoomblock Method: Deleted");
                        }

                        else
                        {
							logger.Info("420 Dynamicgridview Page:Delete Roomblock Method: Entity return value  null");

                        }
                    }

                }
                else
                {
					logger.Info("430 Dynamicgridview Page:Delete Roomblock Method: Room Block records are not available for this user");

                }

				logger.Info("440 Dynamicgridview Page:  DeleteRoomblock Method: End");
            }
			catch (System.Web.Services.Protocols.SoapException ex)
			{
				logger.Error(ex.Detail.InnerText, ex);
			}
            catch (Exception ex)
            {
                logger.Error("Dynamicgridview Page: DeleteRoomblock Method: Error" + ex.ToString());

            }

        }

        private void RoomBlockGrid()
        {
            try
            {
				logger.Info("450 Dynamicgridview Page:  RoomBlockGrid Method: Started");

				if (HttpContext.Current.Request.QueryString["recordid"] == null)
					return;
				string _recordId = Request.QueryString["recordid"].ToString();

				// Get the dates from the event.
				var cols = new ColumnSet(new String[] { "new_arrivaldate", "new_departuredate" });
				var evt = (Opportunity)_service.Retrieve("opportunity", new Guid(_recordId), cols);
				DateTime arrivalDate = evt.New_arrivaldate ?? DateTime.MinValue;
				DateTime departureDate = evt.New_departuredate ?? DateTime.MinValue;

				logger.Info("460 Dynamicgridview Page:  RoomBlockGrid Method:  Input Parameter recordid " + _recordId);
                    string eventID = _recordId.Replace("{", "").Replace("}", "");

                    dtRoomBlock = new DataTable();

                    dtRoomBlock.Columns.Add("DayNumber");
                    dtRoomBlock.Columns.Add("DayofWeek");
                    dtRoomBlock.Columns.Add("Date");
                    dtRoomBlock.Columns.Add("Original % of Peak");
                    dtRoomBlock.Columns.Add("Original Room Block");
                    dtRoomBlock.Columns.Add("Current % of Peak");
                    dtRoomBlock.Columns.Add("CurrentRoom Block");
                    dtRoomBlock.Columns.Add("GUIDID");
                    dtRoomBlock.Columns.Add("RoomGUID");

                    TimeSpan dtTime = departureDate.Subtract(arrivalDate);

                    for (int i = 0; i < dtTime.TotalDays; i++)
                    {
                        DataRow dr = dtRoomBlock.NewRow();
                        dr["DayNumber"] = (i + 1).ToString();
                        dr["DayofWeek"] = arrivalDate.AddDays(i).DayOfWeek.ToString();
                        dr["Date"] = arrivalDate.AddDays(i).ToShortDateString();
                        dr["GUIDID"] = eventID;
                        dtRoomBlock.Rows.Add(dr);
                    }

                    gvRoomBlock.DataSource = dtRoomBlock;
                    gvRoomBlock.DataBind();
                    gvRoomBlock.Columns[0].Visible = false;
                    gvRoomBlock.Columns[7].Visible = false;
                    gvRoomBlock.Columns[8].Visible = false;
                    logger.Info("Dynamicgridview Page: gvFormLoad.Rows.Count :: " + gvFormLoad.Rows.Count);
                    if (gvFormLoad.Rows.Count > 0)
                    {
                        DataTable dt = new DataTable();
                        gvFormLoad.DataSource = dt;
                        gvFormLoad.DataBind();
                        gvFormLoad.Visible = false;
                    }
                }
			catch (System.Web.Services.Protocols.SoapException ex)
			{
				logger.Error(ex.Detail.InnerText, ex);
            }
            catch (Exception ex)
            {
                logger.Error("Dynamicgridview Page: RoomBlockGrid Method: Error" + ex.ToString());
            }
			finally
			{
				logger.Info("470 Dynamicgridview Page:  RoomBlockGrid Method: End");
			}

        }

        private void RetrieveBasedonStatus(OrganizationService _service)
        {
            try
            {
				logger.Info("480 Dynamicgridview Page:  RetrieveBasedonStatus Method: Started");
				if (HttpContext.Current.Request.QueryString["recordid"] == null)
                {
					btnsave.Visible = false;
					btnlead.Visible = false;
				}

                string getRecordid = Request.QueryString["recordid"].ToString();
                string _eventID = getRecordid.Replace("{", "").Replace("}", "");
                ViewState["_eventID"] = _eventID;

				// Get the dates from the event.
				var cols = new ColumnSet(new String[] { "new_arrivaldate", "new_departuredate" });
				var evt = (Opportunity)_service.Retrieve("opportunity", new Guid(_eventID), cols);
				DateTime _arrivaldatedt = evt.New_arrivaldate ?? DateTime.MinValue;
				DateTime _departuredatedt = evt.New_departuredate ?? DateTime.MinValue;

                    try
                    {
					logger.Info("490 Dynamicgridview Page:  RetrieveBasedonStatus Roomblock  Method: Started");

                        // Define the entity attributes (database table columns) that are to be retrieved.

                        New_roompattern entity = new New_roompattern();
                        EntityCollection entityCollection = CheckRoomPatternecords(_eventID, _service);
                        logger.Info("Dynamicgridview Page:  RetrieveBasedonStatus Roomblock  Method: After service execution");

                        Hashtable hshTableRoomPattern = new Hashtable();

                        if (entityCollection.Entities.Count > 0)
                        {
							logger.Info("500 Dynamicgridview Page: entityCollection.BusinessEntities.Length:: " +
								entityCollection.Entities.Count);

                            for (int j = 0; j < entityCollection.Entities.Count; j++)
                            {

                                entity = (New_roompattern)entityCollection.Entities[j];

								logger.Info("510 Dynamicgridview Page:  RetrieveBasedonStatus Roomblock  Method: Retrieve Rooom Pattern Entity Value " + entity);

                                //Added by ZSL Team on 28-06-2012
                                if (entity.Bcmc_Date != null)
                                    hshTableRoomPattern.Add("bcmc_date" + j, entity.Bcmc_Date.Value);
                                else
                                    hshTableRoomPattern.Add("bcmc_date" + j, "01/01/0001");
                            }

                            //Add By  ZSL Team 28-05-2012
                            if (hshTableRoomPattern.Count > 0)
                            {
                                string tempArrivalDateRoomPattern = hshTableRoomPattern["bcmc_date0"].ToString();
							logger.Info("520 Dynamicgridview Page:  Retrieve Roomblock  Method: RetrieveBasedonStatus Rooom Pattern ArrivalDate " + hshTableRoomPattern["bcmc_date0"].ToString());
                                string tempDepartureDateRoomPattern = hshTableRoomPattern["bcmc_date" + (hshTableRoomPattern.Count - 1).ToString()].ToString();
							logger.Info("530 Dynamicgridview Page:  Retrieve Roomblock  Method: RetrieveBasedonStatus Rooom Pattern ArrivalDate " + hshTableRoomPattern["bcmc_date" + (hshTableRoomPattern.Count - 1).ToString()].ToString());

#region Bind Grid

                                if (true)
                                {
                                    if (true)
                                    {
                                        dtretrieve = new DataTable();
                                        dtretrieve.Columns.Add("DayNumber");
                                        dtretrieve.Columns.Add("DayofWeek");
                                        dtretrieve.Columns.Add("Date");
                                        dtretrieve.Columns.Add("Original % of Peak");
                                        dtretrieve.Columns.Add("Original Block");
                                        dtretrieve.Columns.Add("Current % of Peak");
                                        dtretrieve.Columns.Add("Current Block");
                                        dtretrieve.Columns.Add("RoomGUID");
                                        dtretrieve.Columns.Add("GUIDID");

                                        for (int i = 0; i < entityCollection.Entities.Count; i++)
                                        {
											logger.Info("540 Dynamicgridview Page: entityCollection.BusinessEntities.Length:: " +
												entityCollection.Entities.Count);
                                            DataRow drretrieves = dtretrieve.NewRow();

											logger.Info("550 Dynamicgridview Page:  Retrieve Roomblock  Method: RetrieveBasedonStatus Rooom Pattern Entity Name " + entity);
                                            entity = (New_roompattern)entityCollection.Entities[i];

                                            drretrieves["RoomGUID"] = entity.New_roompatternId.Value.ToString();
                                            drretrieves["GUIDID"] = _eventID.ToString();

											logger.Info("560 Dynamicgridview Page:  Retrieve Roomblock  Method: RetrieveBasedonStatus Rooom Pattern Entity - entity new_roompatternid Value.ToString() " + entity.New_roompatternId.Value.ToString());

                                            if (entity.New_DayNumber != null)
                                                //if (!entity.New_DayNumber.IsNull)
                                                {
                                                    drretrieves["DayNumber"] = entity.New_DayNumber.Value;
                                                }
                                                else
                                                {
                                                    drretrieves["DayNumber"] = "0";
                                                }

                                            if (entity.New_name != null)
                                            {
                                                drretrieves["DayofWeek"] = entity.New_name;
                                            }
                                            if (entity.Bcmc_Date != null)
                                                //if (!entity.Bcmc_Date.IsNull)
                                                {
                                                    drretrieves["Date"] = entity.Bcmc_Date.Value.ToShortDateString(); //ytodo ?date of str
                                                }

										// logger.Info("Dynamicgridview Page:  Retrieve Roomblock  Method: RetrieveBasedonStatus Rooom Pattern Entity - entity.bcmc_date.date " + entity.bcmc_date.date);

                                            if (entity.Bcmc_OriginalpercentofPeak != null)
                                            {
                                                //if (!entity.Bcmc_OriginalpercentofPeak.IsNull)
                                                {
                                                    drretrieves["Original % of Peak"] = entity.Bcmc_OriginalpercentofPeak.Value;


												logger.Info("570 Dynamicgridview Page:  Retrieve Roomblock  Method: RetrieveBasedonStatus Rooom Pattern Entity - entity.bcmc_originalpercentofpeak.Value " + entity.Bcmc_OriginalpercentofPeak.Value);
                                                }
                                                btnsave.Text = "Update";
                                                btnlead.Enabled = true;
                                            }
											else
												logger.Info("580 Dynamicgridview Page:  Retrieve Roomblock  Method: RetrieveBasedonStatus Rooom Pattern Entity - entity.bcmc_originalpercentofpeak.Value - null ");

                                            if (entity.Bcmc_OriginalRoomBlock != null)
                                            {
                                                //if (!entity.Bcmc_OriginalRoomBlock.IsNull)
                                                //{
                                                    drretrieves["Original Block"] = entity.Bcmc_OriginalRoomBlock.Value;

												logger.Info("590 Dynamicgridview Page:  Retrieve Roomblock  Method: RetrieveBasedonStatus Rooom Pattern Entity - entity.bcmc_originalroomblock.Value " + entity.Bcmc_OriginalRoomBlock.Value);
                                                //}

                                                btnsave.Text = "Update";
                                                btnlead.Enabled = true;
                                            }
											else
												logger.Info("600 Dynamicgridview Page:  Retrieve Roomblock  Method: RetrieveBasedonStatus Rooom Pattern Entity - entity.bcmc_originalroomblock.Value - null ");

                                            if (entity.New_PercentofPeak != null)
                                            {
                                                //if (!entity.New_PercentofPeak.IsNull)
                                                //{
                                                    drretrieves["Current % of Peak"] = entity.New_PercentofPeak.Value;

												logger.Info("610 Dynamicgridview Page:  Retrieve Roomblock  Method: RetrieveBasedonStatus Rooom Pattern Entity - entity.new_percentofpeak.Value " + entity.New_PercentofPeak.Value);
                                                //}
                                                btnsave.Text = "Update";
                                                btnlead.Enabled = true;
                                            }
											else
												logger.Info("620 Dynamicgridview Page:  Retrieve Roomblock  Method: RetrieveBasedonStatus Rooom Pattern Entity - entity.new_percentofpeak.Value - null ");

											if (entity.New_RoomBlock != null)
                                            {
                                                //if (!entity.New_RoomBlock.IsNull)
                                                //{
                                                    drretrieves["Current Block"] = entity.New_RoomBlock.Value;

												logger.Info("630 Dynamicgridview Page:  Retrieve Roomblock  Method: RetrieveBasedonStatus Rooom Pattern Entity - entity.new_roomblock.Value " + entity.New_RoomBlock.Value);
                                                //}
                                                btnsave.Text = "Update";
                                                btnlead.Enabled = true;
                                            }
											else
												logger.Info("640 Dynamicgridview Page:  Retrieve Roomblock  Method: RetrieveBasedonStatus Rooom Pattern Entity - entity.new_roomblock.Value - null");



										logger.Info("650 Dynamicgridview Page:RetrieveBasedonStatus Roomblock Method: Rows Added in ");
                                            dtretrieve.Rows.Add(drretrieves);

                                        }

                                        gvFormLoad.DataSource = dtretrieve;
                                        gvFormLoad.DataBind();

                                        bool dateFLag = false;

                                        Hashtable hshDateCollections = new Hashtable();

                                        for (int i = 0; i < dtretrieve.Rows.Count; i++)
                                        {
                                            string getDate = dtretrieve.Rows[i]["Date"].ToString();

										logger.Info("660 Dynamicgridview Page:RetrieveBasedonStatus Roomblock Method: Rows Added in getDate " + getDate.ToString());

                                            string roomID = dtretrieve.Rows[i]["RoomGUID"].ToString();

										logger.Info("670 Dynamicgridview Page:RetrieveBasedonStatus Roomblock Method: Rows Added in Room ID " + roomID.ToString());


                                            //Added this code for check the existing records in crm, if those records does not having the date and has null means, we check the record and update it.

                                            // Added by ZSL team on 27th July 2012.

                                            EntityCollection rp_Records_Entities = FindRoomPatternDates(_eventID, _service);

                                            if (rp_Records_Entities.Entities.Count == 0)
                                            {

											if (!CheckDateExists(_arrivaldatedt.ToString("s"), _departuredatedt.ToString("s"), getDate))
                                                {
												logger.Info("680 RetrieveBasedonStatus Method CheckDateExists Method Checked, Room pattern Entity update process started");
                                                    New_roompattern roomEvent = new New_roompattern();
                                                    roomEvent.New_roompatternId = new Guid(roomID);
                                                    int currntroomblock = 0;
                                                    roomEvent.New_RoomBlock = currntroomblock;
                                                    dtretrieve.Rows[i]["Current Block"] = "";
                                                    roomEvent.New_PercentofPeak = 0;
                                                    dtretrieve.Rows[i]["Current % of Peak"] = "";
                                                    //Commented by ZSL Team on July 27th 2012
												//  _service.Update(roomEvent);*/
												logger.Info("690 RetrieveBasedonStatus Method CheckDateExists Method Checked, Room pattern Entity update completed");
                                                }
                                            }
                                            else
                                            {
                                                dateFLag = true;
											hshDateCollections = ProcessDateIsNull(_arrivaldatedt.ToString("s"), _departuredatedt.ToString("s"));
                                                break;
                                            }

                                        }
                                        dtRoomBlock = dtretrieve;
                                        gvFormLoad.DataSource = dtretrieve;
                                        gvFormLoad.DataBind();

                                        for (int i = 0; i < dtretrieve.Rows.Count; i++)
                                        {
                                            string getDate = dtretrieve.Rows[i]["Date"].ToString();
                                            string roomID = dtretrieve.Rows[i]["RoomGUID"].ToString();

										if (!dateFLag && !CheckDateExists(_arrivaldatedt.ToString("s"), _departuredatedt.ToString("s"), getDate))
                                            {
											logger.Info("700 RetrieveBasedonStatus Method CheckDateExists Method Checked, Gridview Row Disabled on this date " + getDate.ToString());
                                                gvFormLoad.Rows[i].Enabled = false;
                                            }

									}




                                        gvFormLoad.Columns[7].Visible = false;
                                        gvFormLoad.Columns[0].Visible = false;
                                        gvFormLoad.Visible = true;

                                        if (gvFormLoad.Rows.Count > 0)
                                        {

                                            DataTable dt = new DataTable();
                                            gvRoomBlock.DataSource = dt;
                                            gvRoomBlock.DataBind();
                                            gvRoomBlock.Visible = false;
                                        }
                                    }
                                }

		#endregion
                            }

                        }
                        else
                        {
                            RoomBlockGrid();
                        }
					logger.Info("710 Dynamicgridview Page:RetrieveBasedonStatus Roomblock Method: End");
                    }
				catch (System.Web.Services.Protocols.SoapException ex)
				{
					logger.Error(ex.Detail.InnerText, ex);
				}
                    catch (Exception ex)
                    {
					logger.Error("720 Dynamicgridview Page: RetrieveBasedonStatus Roomblock  Method: Error" + ex.ToString());
                    }
                }
			catch (System.Web.Services.Protocols.SoapException ex)
                {
				logger.Error(ex.Detail.InnerText, ex);
                }
			catch (Exception ex)
			{
				logger.Error("730 Dynamicgridview Page: RetrieveBasedonStatus Roomblock  Method: Error" + ex.ToString());

            }
			finally
            {
				logger.Info("740 Dynamicgridview Page:RetrieveBasedonStatus Roomblock Method: End");

            }

        }

        private Hashtable ProcessDateIsNull(string _arrivaldate, string __departuredate)
        {
            Hashtable hshDateCollections = new Hashtable();
            try
            {
				logger.Info("750 Dynamicgridview Page:  ProcessDateIsNull   Method: Started");
                DateTime departureDate = Convert.ToDateTime((Convert.ToDateTime(__departuredate)).ToString("MM/dd/yyyy"));
				//logger.Info("CheckDateExists Method: ProcessDateIsNull:Departure Date: " + departureDate);
                DateTime arrivalDate = Convert.ToDateTime((Convert.ToDateTime(_arrivaldate)).ToString("MM/dd/yyyy"));
				//logger.Info("CheckDateExists Method: ProcessDateIsNull:Arrival Date: " + departureDate);

                TimeSpan dtTime = departureDate.Subtract(arrivalDate);

                for (int i = 0; i < dtTime.TotalDays; i++)
                {
                    hshDateCollections.Add(i, arrivalDate.AddDays(i).ToString("MM/dd/yyyy"));
                }
				//logger.Info("ProcessDateIsNull Method: compared dates Failed. No Same dates found.");
            }
			catch (System.Web.Services.Protocols.SoapException ex)
			{
				logger.Error(ex.Detail.InnerText, ex);
			}
            catch (Exception ex)
            {
                logger.Error("ProcessDateIsNull Method: Error" + ex.ToString());
                // throw;
            }
            return hshDateCollections;
        }

        private bool CheckDateExists(string _arrivaldate, string __departuredate, string currentArrDate)
        {
            try
            {
				logger.Info("760 Dynamicgridview Page:  CheckDateExists   Method: Started");

                DateTime departureDate = Convert.ToDateTime((Convert.ToDateTime(__departuredate)).ToString("MM/dd/yyyy"));
				//logger.Info("CheckDateExists Method: compared dates Success " + departureDate);
                DateTime arrivalDate = Convert.ToDateTime((Convert.ToDateTime(_arrivaldate)).ToString("MM/dd/yyyy"));
				//logger.Info("CheckDateExists Method: compared dates Success " + arrivalDate);
                DateTime getArrDate = Convert.ToDateTime((Convert.ToDateTime(currentArrDate)).ToString("MM/dd/yyyy"));
				//logger.Info("CheckDateExists Method: Get process date " + getArrDate);
                TimeSpan dtTime = departureDate.Subtract(arrivalDate);

                for (int i = 0; i < dtTime.TotalDays; i++)
                {
                    if (getArrDate.ToString("MM/dd/yyyy") == arrivalDate.AddDays(i).ToString("MM/dd/yyyy"))
                    {
						logger.Info("770 CheckDateExists Method: compared dates Success " + getArrDate);
                        return true;
                    }
                }
				logger.Info("780 CheckDateExists Method: compared dates Failed. No Same dates found.");
            }
			catch (System.Web.Services.Protocols.SoapException ex)
			{
				logger.Error(ex.Detail.InnerText, ex);
			}
            catch (Exception ex)
            {
                logger.Error("CheckDateExists Method: Error" + ex.ToString());
                // throw;
            }
            return false;
        }

        private string CheckEventStatus(OrganizationService _service, string getRecordid)
        {

			logger.Info("790 Dynamicgridview Page: Page_Load Method: CheckEventStatus Method Started");
            string getstatusCode = "";
            try
            {
                ColumnSet columnSet = new ColumnSet(new string[] { "bcmc_eventname", "statuscode" });

                ConditionExpression condition_new_eventid = new ConditionExpression();
                condition_new_eventid.AttributeName = "opportunityid";
                condition_new_eventid.Operator = ConditionOperator.Equal;
                condition_new_eventid.Values.Add(getRecordid);

                FilterExpression filter_Eventid = new FilterExpression();
                filter_Eventid.Conditions.Add(condition_new_eventid);

                // Create the query.
                QueryExpression query = new QueryExpression();

                // Set the properties of the query.
                query.ColumnSet = columnSet;
                query.Criteria = filter_Eventid;
                query.EntityName = Opportunity.EntityLogicalName;

                EntityCollection entityCollection = _service.RetrieveMultiple(query);
                Hashtable hshTableOpportunity = new Hashtable();
                if (entityCollection.Entities.Count > 0)
                {
					logger.Info("800 Dynamicgridview Page: entityCollection.BusinessEntities.Length:: " + entityCollection.Entities.Count);

                    for (int j = 0; j < entityCollection.Entities.Count; j++)
                    {
                        Opportunity opportunity = (Opportunity)entityCollection.Entities[j];
                        getstatusCode = opportunity.StatusCode.Value.ToString();
                    }
                }
            }
			catch (System.Web.Services.Protocols.SoapException ex)
			{
				logger.Error(ex.Detail.InnerText, ex);
			}
            catch (Exception ex)
            {

                logger.Error("CheckEventStatus Method" + ex.ToString());
            }

            return getstatusCode;
        }

		private EntityCollection CheckRoomPatternecords(string _eventID, OrganizationService _service)
        {
			logger.Info("810 Dynamicgridview Page:  CheckRoomPatternecords Roomblock  Method: Started");

            // Create a retrieve request object.
            ConditionExpression condition_new_eventid = new ConditionExpression();
            condition_new_eventid.AttributeName = "new_eventid";
            condition_new_eventid.Operator = ConditionOperator.Equal;
            condition_new_eventid.Values.Add(_eventID);
			logger.Info("820 Dynamicgridview Page:   CheckRoomPatternecords Method: new_eventid = " + _eventID);

            OrderExpression ordeErp = new OrderExpression();
            ordeErp.AttributeName = "bcmc_date";
            ordeErp.OrderType = OrderType.Ascending;

            FilterExpression filter_Eventid = new FilterExpression();
            // Set the properties of the FilterExpression.            
            filter_Eventid.Conditions.Add(condition_new_eventid);

            // Create the query.
            QueryExpression query = new QueryExpression();
            // Set the properties of the query.
            query.ColumnSet.AddColumns(new string[] { "new_daynumber", "new_name", "bcmc_date", "new_percentofpeak", "bcmc_originalpercentofpeak", "bcmc_originalroomblock", "new_roomblock" });
            query.Criteria = filter_Eventid;
            query.Orders.Add(ordeErp);
            query.EntityName = New_roompattern.EntityLogicalName;
			logger.Info("830 Dynamicgridview Page:  CheckRoomPatternecords Roomblock  Method: Before service execution");
            EntityCollection entityCollection = _service.RetrieveMultiple(query);
			logger.Info("840 Dynamicgridview Page:  CheckRoomPatternecords Roomblock  Method: After service execution");

            return entityCollection;
        }

        private EntityCollection FindRoomPatternDates(string _eventID, OrganizationService _service)
        {
			logger.Info("850 Dynamicgridview Page:  FindRoomPatternDates   Method: Started");
            ColumnSet columnSet = new ColumnSet(new string[] { "new_daynumber", "new_name", "bcmc_date", "new_percentofpeak", "bcmc_originalpercentofpeak", "bcmc_originalroomblock", "new_roomblock" });
            // Create a retrieve request object.
            ConditionExpression condition_new_eventid = new ConditionExpression();
            condition_new_eventid.AttributeName = "new_eventid";
            condition_new_eventid.Operator = ConditionOperator.Equal;
            condition_new_eventid.Values.Add(_eventID);
			logger.Info("860 Dynamicgridview Page:   FindRoomPatternDates Method: new_eventid = " + _eventID);

            ConditionExpression condition_date = new ConditionExpression();
            condition_date.AttributeName = "bcmc_date";
            condition_date.Operator = ConditionOperator.Null;

            FilterExpression filter_Eventid = new FilterExpression();
            // Set the properties of the FilterExpression.
            filter_Eventid.FilterOperator = LogicalOperator.And;
            filter_Eventid.Conditions.AddRange( new ConditionExpression[] { condition_new_eventid, condition_date });

            // Create the query.
            QueryExpression query = new QueryExpression();

            // Set the properties of the query.
            query.ColumnSet = columnSet;
            query.Criteria = filter_Eventid;

            query.EntityName = New_roompattern.EntityLogicalName;
			logger.Info("870 Dynamicgridview Page:  FindRoomPatternDates   Method: Before service execution");
            EntityCollection entityCollection = _service.RetrieveMultiple(query);
			logger.Info("880 Dynamicgridview Page:  FindRoomPatternDates   Method: After service execution");
            return entityCollection;
        }

        private void BindSave(string _eventID)
        {
            try
            {
				logger.Info("890 Dynamicgridview Page:   SaveRoomBlockGrid Method: Started");
                Guid crmguid = Guid.Empty;
				logger.Info("900 Dynamicgridview Page:   gvRoomBlock.Rows.Count " + gvRoomBlock.Rows.Count);
              
                for (int i = 0; i < gvRoomBlock.Rows.Count; i++)
                {
                    int daynumber = Convert.ToInt32(dtRoomBlock.Rows[i]["DayNumber"]);
                    string new_week = dtRoomBlock.Rows[i]["DayofWeek"].ToString();

					logger.Info("910 Dynamicgridview Page:   SaveRoomBlockGrid Method: DayofWeek " + gvRoomBlock.Rows[i].Cells[1].Text);

                    DateTime roomblockdate = Convert.ToDateTime(dtRoomBlock.Rows[i]["Date"]);

					logger.Info("920 Dynamicgridview Page:   SaveRoomBlockGrid Method: Date " + roomblockdate.ToShortDateString());

					int new_originalpeak = 0;
                    if ((((System.Web.UI.WebControls.Label)(gvRoomBlock.Rows[i].FindControl("lblOPeak"))).Text != string.Empty) && ((System.Web.UI.WebControls.Label)(gvRoomBlock.Rows[i].FindControl("lblOPeak"))).Text != null)
                    {
                        if (((System.Web.UI.WebControls.Label)(gvRoomBlock.Rows[i].FindControl("lblOPeak"))).Text.Contains("."))
                        {
							new_originalpeak = Convert.ToInt32(((System.Web.UI.WebControls.Label)(gvRoomBlock.Rows[i].FindControl("lblOPeak"))).Text.Split('.')[0].ToString());
                        }
                        else
							new_originalpeak = Convert.ToInt32(((System.Web.UI.WebControls.Label)(gvRoomBlock.Rows[i].FindControl("lblOPeak"))).Text);
                    }


					//logger.Info("#################################   SaveRoomBlockGrid Method:  Original % Of  Peak        #####################################################");
					logger.Info("930 new_originalpeak.Value = " + new_originalpeak.ToString());
					//logger.Info("#################################   SaveRoomBlockGrid Method: Original % Of  Peak          ##############################################");


                    int new_Original = 0;

                    if ((((System.Web.UI.WebControls.Label)(gvRoomBlock.Rows[i].FindControl("lblOblock"))).Text != string.Empty) && ((System.Web.UI.WebControls.Label)(gvRoomBlock.Rows[i].FindControl("lblOblock"))).Text != null)
                    {
                        new_Original = Convert.ToInt32(((System.Web.UI.WebControls.Label)(gvRoomBlock.Rows[i].FindControl("lblOblock"))).Text);
                    }

					//logger.Info("###############################  SaveRoomBlockGrid Method:  Original RoomBlock  #################################################");
					logger.Info("940  new_Original.Value " + new_Original);
					//logger.Info("############################### SaveRoomBlockGrid Method:  Original RoomBlock    ############################################");

                    int new_percentofpeak = 0;

                    if ((((HiddenField)(gvRoomBlock.Rows[i].FindControl("hdnfdValue"))).Value != string.Empty) && ((HiddenField)(gvRoomBlock.Rows[i].FindControl("hdnfdValue"))) != null)
                    {
                        if (((HiddenField)(gvRoomBlock.Rows[i].FindControl("hdnfdValue"))).Value.Contains("."))
                        {
                            new_percentofpeak = Convert.ToInt32(((HiddenField)(gvRoomBlock.Rows[i].FindControl("hdnfdValue"))).Value.Split('.')[0].ToString());
                        }
                        else
                            new_percentofpeak = Convert.ToInt32(((HiddenField)(gvRoomBlock.Rows[i].FindControl("hdnfdValue"))).Value);
                    }
                    else
                    {
                        new_percentofpeak = 0;
                    }

					//logger.Info("##################################  SaveRoomBlockGrid Method:   % Of Peak         #####################################");
					logger.Info("950 new_percentofpeak.Value = " + new_percentofpeak);
					//logger.Info("##################################  SaveRoomBlockGrid Method:  % Of Peak      #######################################");

                    int new_Current = 0;

                    if ((((TextBox)(gvRoomBlock.Rows[i].FindControl("txtCBlock"))).Text != string.Empty) && ((TextBox)(gvRoomBlock.Rows[i].FindControl("txtCBlock"))).Text != null)
                    {
                        new_Current = Convert.ToInt32(((TextBox)gvRoomBlock.Rows[i].FindControl("txtCBlock")).Text);
                    }
                    else
                    {
                        new_Current = 0;
                    }

					//logger.Info("##################################  SaveRoomBlockGrid Method: Current RoomBlock   #########################################");
					logger.Info("960  new_Current.Value " + new_Current);
					//logger.Info("###############################    SaveRoomBlockGrid Method: Current RoomBlock    ##########################################. NS20: " + _eventID);

                    //Instantiate a lookup property.
                    EntityReference new_eventid = new EntityReference("opportunity", new Guid(_eventID));
					//NS 5/27/13 new_eventid.Value.Value = new Guid(dtRoomBlock.Rows[i]["GUIDID"].ToString());

					//logger.Info("Dynamicgridview Page:   SaveRoomBlockGrid Method:  new_eventid  " + dtRoomBlock.Rows[i]["GUIDID"].ToString());

                    // Create the DynamicEntity object.
                    Entity myroomblock = new Entity(New_roompattern.EntityLogicalName);
					myroomblock["new_daynumber"] = daynumber;
					myroomblock["new_name"] = new_week;
					myroomblock["bcmc_date"] = roomblockdate;
					myroomblock["bcmc_originalpercentofpeak"] = new_originalpeak;
					myroomblock["bcmc_originalroomblock"] = new_Original;
					myroomblock["new_percentofpeak"] = new_percentofpeak;
					myroomblock["new_roomblock"] = new_Current;
					myroomblock["new_eventid"] = new_eventid;

					logger.Info("970 Dynamicgridview Page:  SaveRoomBlockGrid Method: Before create the Roomblocks inside the Roompattern");
                    // Execute the request.
					crmguid = _service.Create(myroomblock);
					logger.Info("980 Dynamicgridview Page:  SaveRoomBlockGrid Method: After Created Roomblocks Successfully in Roompattern ");

                    dtRoomBlock.Rows[i]["RoomGUID"] = crmguid.ToString();

					logger.Info("990 Dynamicgridview Page:   SaveRoomBlockGrid Method: RoomPatternGuid " + dtRoomBlock.Rows[i]["RoomGUID"].ToString());

                }
				String jsCode = BindPeakroom(gvRoomBlock, _eventID);


                //if (crmguid != Guid.Empty && oppguid != Guid.Empty)
                if (crmguid != Guid.Empty)
                {
					string myscript = jsCode + "alert('Successfully saved ');";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "myscript", myscript, true);
                    btnsave.Text = "Update";
                    btnlead.Enabled = true;
                }
                Retrieve(_service, true,0);
                btnlead.Enabled = true;

				logger.Info("1000 Dynamicgridview Page:  SaveRoomBlockGrid Method: End");
            }
			catch (System.Web.Services.Protocols.SoapException ex)
			{
				logger.Error(ex.Detail.InnerText, ex);
			}
            catch (Exception ex)
            {
                logger.Error("Dynamicgridview Page: SaveRoomBlockGrid Method: Error" + ex.ToString());
            }
        }

#region NewUpdate for Recomended solution
		private void UpdateRoomblock1(string _eventID, int Updatestatus)
        {
            try
            {
				string getRecordid = Request.QueryString["recordid"].ToString();
               
				// Get the dates from the event.
				var cols = new ColumnSet(new String[] { "new_arrivaldate", "new_departuredate" });
				var evt = (Opportunity)_service.Retrieve("opportunity", new Guid(getRecordid), cols);
				DateTime _arrivaldatedt = evt.New_arrivaldate ?? DateTime.MinValue;
				DateTime _departuredatedt = evt.New_departuredate ?? DateTime.MinValue;

				try
				{
					logger.Info("1010 Dynamicgridview Page:  Update Roomblock  Method: Started. NS100 Method not used.");

					// Define the entity attributes (database table columns) that are to be retrieved.

					New_roompattern entity = new New_roompattern();

					EntityCollection entityCollection = CheckRoomPatternecords(_eventID, _service);
					logger.Info("1020 Dynamicgridview Page:  Update Roomblock  Method: After service execution");
					Hashtable hshTableRoomPattern = new Hashtable();
					if (entityCollection.Entities.Count == 0)
						return;
					logger.Info("1030 Dynamicgridview Page: entityCollection.BusinessEntities.Length:: " + entityCollection.Entities.Count);

					for (int j = 0; j < entityCollection.Entities.Count; j++)
					{
						entity = (New_roompattern)entityCollection.Entities[j];

						//Added by ZSL Team on 28-06-2012
						if (entity.Bcmc_Date != null)
							hshTableRoomPattern.Add("bcmc_date" + j, entity.Bcmc_Date.Value);
						else
							hshTableRoomPattern.Add("bcmc_date" + j, "01/01/0001");
					}
					DataRow drretrieve = dtretrieve.NewRow();

					//Add By ZSL Team 28/05/2012
					if (hshTableRoomPattern.Count > 0)
					{
						string tempArrivalDateRoomPattern = hshTableRoomPattern["bcmc_date0"].ToString();

						if (tempArrivalDateRoomPattern != "01/01/0001")
						{
							logger.Info("1040 Dynamicgridview Page:  Update Roomblock  Method: Retrieve Rooom Pattern ArrivalDate " + hshTableRoomPattern["bcmc_date0"].ToString());
							string tempDepartureDateRoomPattern = hshTableRoomPattern["bcmc_date" + (hshTableRoomPattern.Count - 1).ToString()].ToString();
							logger.Info("1050 Dynamicgridview Page:  Update Roomblock  Method: Retrieve Rooom Pattern ArrivalDate " + hshTableRoomPattern["bcmc_date" + (hshTableRoomPattern.Count - 1).ToString()].ToString());

							DateTime dtdeparture = _departuredatedt;
							dtdeparture = dtdeparture.AddDays(-1);
							string _Departuredate = Convert.ToString(dtdeparture.ToShortDateString());

							DateTime dtTempArrTime = Convert.ToDateTime(tempArrivalDateRoomPattern);
							DateTime dtArrivalDate = _arrivaldatedt;

							DateTime dtTempDepTime = Convert.ToDateTime(tempDepartureDateRoomPattern);
							DateTime dtDeparturedate = Convert.ToDateTime(_Departuredate);

							logger.Info("1060 Arrival Date Check dtArrivalDate: + " + dtArrivalDate.ToString());
							logger.Info("1070 Arrival Date Check dtTempArrTime: + " + dtTempArrTime.ToString());

							//logger.Info("Dynamicgridview Page:   UpdateRoomblock Method: Started");

                if (gvFormLoad.Rows.Count > 0)
                {
                    for (int i = 0; i < gvFormLoad.Rows.Count; i++)
                    {
                        // Create the RoomPattern object.
                        New_roompattern roompattern = new New_roompattern();
                        // Set the RoomPattern object properties to be updated.
                        HiddenField txtcurrentpercent = (HiddenField)gvFormLoad.Rows[i].FindControl("hdnfdValue");

                        string CPeak = txtcurrentpercent.Value;

                        int intCPeak = 0;
                        if ((((HiddenField)(gvFormLoad.Rows[i].FindControl("hdnfdValue"))).Value != string.Empty) && ((HiddenField)(gvFormLoad.Rows[i].FindControl("hdnfdValue"))) != null)
                        {
                            if (CPeak.Contains("."))
                            {
                                intCPeak = Convert.ToInt32(CPeak.Split('.')[0].ToString());
                            }
                            else
                            {
                                intCPeak = Convert.ToInt32(CPeak);
                            }
                        }
                        roompattern.New_PercentofPeak = intCPeak;
									//logger.Info("################################  UpdateRoomblock Method:   % Of Peak        ########################################################");
									logger.Info("1080 roompattern.new_percentofpeak = " + roompattern.New_PercentofPeak);
									//logger.Info("################################## UpdateRoomblock Method:   % Of Peak        #######################################################");


                        TextBox txtcurrentroom = (TextBox)gvFormLoad.Rows[i].FindControl("txtCBlock");
                        string CRoom = txtcurrentroom.Text;
                     
                        int intCRoom = 0;
                        if ((((TextBox)(gvFormLoad.Rows[i].FindControl("txtCBlock"))).Text != string.Empty) && ((TextBox)(gvFormLoad.Rows[i].FindControl("txtCBlock"))).Text != null)
                        {
                            if (CRoom.Contains("."))
                            {
                                intCRoom = Convert.ToInt32(CRoom.Split('.')[0].ToString());
                            }
                            else
                            {
                                intCRoom = Convert.ToInt32(CRoom);
                            }
                        }

                        roompattern.New_RoomBlock = intCRoom;

									//logger.Info("#################################  UpdateRoomblock Method: Current RoomBlock   #######################################");
									logger.Info("1090  roompattern.new_roomblock " + roompattern.New_RoomBlock.Value);
									//logger.Info("################################  UpdateRoomblock Method:Current RoomBlock   #########################################");

                        // The RoomPatternid is a key that references the ID of the RoomPattern to be updated.
                        // The RoomPatternid.Value is the GUID of the record to be changed.
                        roompattern.New_roompatternId = new Guid(dtretrieve.Rows[i]["RoomGUID"].ToString());
                        logger.Info("Dynamicgridview Page:   UpdateRoomBlockGrid Method: RoomPatternGuid " + dtretrieve.Rows[i]["RoomGUID"].ToString());

                        // Update the RoomPattern.

									//logger.Info("--------------------------------    UpdateRoomblock Method    -------------------------------------------------");
									logger.Info("1100 roompattern.new_percentofpeak = " + roompattern.New_PercentofPeak + "- roompattern.new_roomblock " + roompattern.New_RoomBlock);
									// logger.Info("----------------------------------  UpdateRoomblock Method  ---------------------------------------------------");
                        
									//logger.Info("Dynamicgridview Page:  UpdateRoomblock Method: Before Update ");
                        _service.Update(roompattern);
									logger.Info("1110 Dynamicgridview Page:  UpdateRoomblock Method: Updated Successfully");

                    }
                    // Update an attribute retrieved via RetrieveAttributeRequest
					String jsCode = BindPeakroom(gvFormLoad, _eventID);

                    if (Updatestatus == 1)
                    {
						string myscript = jsCode + "alert('Successfully updated ');";
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "myscript", myscript, true);
                    }
                    Retrieve(_service, true,0);
                    btnlead.Enabled = true;
                }

               //if (gvRoomBlock.Columns.Count == 9)
                else if (gvRoomBlock.Rows.Count > 0)
                {
                    //DeleteRoomblock(_eventID);
                    for (int i = 0; i < gvRoomBlock.Rows.Count; i++)
                    {
                        // Create the RoomPattern object.
                        New_roompattern roompattern = new New_roompattern();
                        // Set the RoomPattern object properties to be updated.
                        HiddenField txtcurrentpercent = (HiddenField)gvRoomBlock.Rows[i].FindControl("hdnfdValue");
                        string CPeak = txtcurrentpercent.Value;

                        int intCPeak = 0;
                        if ((((HiddenField)(gvRoomBlock.Rows[i].FindControl("hdnfdValue"))).Value != string.Empty) && ((HiddenField)(gvRoomBlock.Rows[i].FindControl("hdnfdValue"))) != null)
                        {
                            if (CPeak.Contains("."))
                            {
                                intCPeak = Convert.ToInt32(CPeak.Split('.')[0].ToString());
                            }
                            else
                            {
                                intCPeak = Convert.ToInt32(CPeak);
                            }
                        }
                        roompattern.New_PercentofPeak = intCPeak;

									//logger.Info("############################### UpdateRoomBlock Method : % Of Peak    ###################################################");
									logger.Info("1120 roompattern.new_percentofpeak= " + roompattern.New_PercentofPeak);
									//logger.Info("############################### UpdateRoomBlock Method : % Of Peak   ###################################################");



                        TextBox txtcurrentroom = (TextBox)gvRoomBlock.Rows[i].FindControl("txtCBlock");
                        string CRoom = txtcurrentroom.Text;

                        
                        int intCRoom = 0;

                        if ((((TextBox)(gvRoomBlock.Rows[i].FindControl("txtCBlock"))).Text != string.Empty) && ((TextBox)(gvRoomBlock.Rows[i].FindControl("txtCBlock"))).Text != null)
                        {
                            if (CRoom.Contains("."))
                            {
                                intCRoom = Convert.ToInt32(CRoom.Split('.')[0].ToString());
                            }
                            else
                            {
                                intCRoom = Convert.ToInt32(CRoom);
                            }
                        }
                        roompattern.New_RoomBlock = intCRoom;

									//logger.Info("############################     UpdateRoomBlock Method : Current RoomBlock   ###########################################");
									logger.Info("1130 roompattern.new_roomblock " + roompattern.New_RoomBlock);
									//logger.Info("##############################  UpdateRoomBlock Method : Current RoomBlock   #########################################");
                        // The roompatternid is a key that references the ID of the RommPattern to be updated.
						roompattern.New_roompatternId = new Guid(_eventID);  //NS10. This update can't be right!! Looks like the whole method is no longer called
                      
                        // Update the RommPattern.                     
									//logger.Info("-----------------------------------        UpdateRoomBlock Method  ----------------------------------");
									logger.Info("1140 _eventID = " + _eventID + " roompattern.new_percentofpeak = " + roompattern.New_PercentofPeak + "- roompattern.new_roomblock " + roompattern.New_RoomBlock);
									//logger.Info("-----------------------------------       UpdateRoomBlock Method  -------------------------------");
                       if(_service !=null )
										//logger.Info("Dynamicgridview Page:  UpdateRoomblock Method: Before Update ");
										_service.Update(roompattern);
									//logger.Info("Dynamicgridview Page:  UpdateRoomblock Method: Updated Successfully");
								}

								String jsCode = BindPeakroom(gvRoomBlock, _eventID);

								string myscript = jsCode + "alert('Successfully updated ');";
								Page.ClientScript.RegisterStartupScript(this.GetType(), "myscript", myscript, true);
                     
								Retrieve(_service, true, 0);
								btnlead.Enabled = true;
                    }
                        }
                        else
                        {
							DisplayNullDateRecords(entityCollection);
                        }
					}
				}
				catch (System.Web.Services.Protocols.SoapException ex)
                {
					logger.Error(ex.Detail.InnerText, ex);
                }
				catch (Exception ex)
                {
					logger.Error("Ex:Dynamicgridview Page:  UpdateRoomblock Method: Error" + ex.ToString());
                }
            }
			catch (System.Web.Services.Protocols.SoapException ex)
			{
				logger.Error(ex.Detail.InnerText, ex);
            }
            catch (Exception ex)
            {
                logger.Error("Ex1:Dynamicgridview Page:  UpdateRoomblock Method: Error" + ex.ToString());
            }
			finally
			{
				logger.Info("1150 Dynamicgridview Page:  UpdateRoomblock Method: End");
			}
        }
		#endregion

#region Original Update
		private void UpdateRoomblock(string _eventID, int Updatestatus)
        {
            try
            {
				logger.Info("1160 Dynamicgridview Page:   UpdateRoomblock Method: Started. NS 101 Is this called? ");

                if (gvFormLoad.Rows.Count > 0)
                {
                    for (int i = 0; i < gvFormLoad.Rows.Count; i++)
                    {
                        // Create the RoomPattern object.
                        New_roompattern roompattern = new New_roompattern();
						roompattern.New_roompatternId = new Guid(dtretrieve.Rows[i]["RoomGUID"].ToString());
						logger.Info("1165 UpdateRoomBlockGrid.RoomPatternGuid= " + dtretrieve.Rows[i]["RoomGUID"].ToString());

                        // Set the RoomPattern object properties to be updated.
                        HiddenField txtcurrentpercent = (HiddenField)gvFormLoad.Rows[i].FindControl("hdnfdValue");
                        string CPeak = txtcurrentpercent.Value;
                        int intCPeak = 0;
                        if (null != txtcurrentpercent &&
							txtcurrentpercent.Value != string.Empty)
                        {
                            if (CPeak.Contains("."))
                                intCPeak = Convert.ToInt32(CPeak.Split('.')[0].ToString());
                            else
                                intCPeak = Convert.ToInt32(CPeak);
                        }
                        roompattern.New_PercentofPeak = intCPeak;
						logger.Info("1170 roompattern.new_percentofpeak (% Of Peak) = " + roompattern.New_PercentofPeak);

						TextBox txtcurrentroom = (TextBox)gvFormLoad.Rows[i].FindControl("txtCBlock");
						string CRoom = txtcurrentroom.Text;
                        int intCRoom = 0;
                        if (null != txtcurrentroom 
							&& txtcurrentroom.Text != string.Empty)
                        {
                            if (CRoom.Contains("."))
                                intCRoom = Convert.ToInt32(CRoom.Split('.')[0].ToString());
                            else
                                intCRoom = Convert.ToInt32(CRoom);
                        }
                        roompattern.New_RoomBlock = intCRoom;
						logger.Info("1180  roompattern.new_roomblock (Current RoomBlock)= " + roompattern.New_RoomBlock);

                        _service.Update(roompattern);
						logger.Info("1210 Dynamicgridview Page:  UpdateRoomblock Method: Updated Successfully");
                    }

					// Update an attribute retrieved via RetrieveAttributeRequest
					String jsCode = BindPeakroom(gvFormLoad, _eventID);
                    if (Updatestatus == 1)
                    {
						string myscript = jsCode + "alert('Successfully updated ');";
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "myscript", myscript, true);
                    }

					Retrieve(_service, true, 0);
                    btnlead.Enabled = true;
                }
                else if (gvRoomBlock.Rows.Count > 0)
                {
                    for (int i = 0; i < gvRoomBlock.Rows.Count; i++)
                    {
                        // Create the RoomPattern object.
                        New_roompattern roompattern = new New_roompattern();
						roompattern.New_roompatternId = new Guid(dtretrieve.Rows[i]["RoomGUID"].ToString());

						// Set the RoomPattern object properties to be updated.
						HiddenField txtcurrentpercent = (HiddenField)gvRoomBlock.Rows[i].FindControl("hdnfdValue");
						string CPeak = txtcurrentpercent.Value;
						int intCPeak = 0;
						if (null != txtcurrentpercent && (txtcurrentpercent.Value != string.Empty))
                        {
                            if (CPeak.Contains("."))
                            {
                                intCPeak = Convert.ToInt32(CPeak.Split('.')[0].ToString());
                            }
                            else
                            {
                                intCPeak = Convert.ToInt32(CPeak);
                            }
                        }
                        roompattern.New_PercentofPeak = intCPeak;
						logger.Info("1220 roompattern.new_percentofpeak (% Of Peak)= " + roompattern.New_PercentofPeak);

                        TextBox txtcurrentroom = (TextBox)gvRoomBlock.Rows[i].FindControl("txtCBlock");
                        string CRoom = txtcurrentroom.Text;
                        int intCRoom = 0;
                        if (null != txtcurrentroom &&
							txtcurrentroom.Text != string.Empty)
                        {
                            if (CRoom.Contains("."))
                            {
                                intCRoom = Convert.ToInt32(CRoom.Split('.')[0].ToString());
                            }
                            else
                            {
                                intCRoom = Convert.ToInt32(CRoom);
                            }
                        }
						roompattern.New_RoomBlock = intCRoom;
						logger.Info("1230 roompattern.new_roomblock (Current RoomBlock)= " + roompattern.New_RoomBlock);

						logger.Info("1240 _eventID = " + _eventID + 
							" roompattern.new_percentofpeak = " + roompattern.New_PercentofPeak + 
							"- roompattern.new_roomblock " + roompattern.New_RoomBlock);
						if (_service != null)
							_service.Update(roompattern);
                    }

					String jsCode = BindPeakroom(gvRoomBlock, _eventID);
					Page.ClientScript.RegisterStartupScript(this.GetType(), "myscript",
						jsCode + "alert('Successfully updated ');", 
						true);

					Retrieve(_service, true, 0);
					btnlead.Enabled = true;
				}
				logger.Info("1250 Dynamicgridview Page:  UpdateRoomblock Method: End");
			}
			catch (System.Web.Services.Protocols.SoapException ex)
            {
				logger.Error(ex.Detail.InnerText, ex);
			}
			catch (Exception ex)
            {
				logger.Error("1251 Dynamicgridview Page:  UpdateRoomblock Method: Error" + ex.ToString());
            }
		}
		#endregion

#region NewUpdateStatus Recomended solution
		private void UpdateRoomblockStatus1(string _eventID, int Updatestatus)
		{
			try
			{
				string getRecordid = Request.QueryString["recordid"].ToString();

				// Get the dates from the event.
				var cols = new ColumnSet(new String[] { "new_arrivaldate", "new_departuredate" });
				var evt = (Opportunity)_service.Retrieve("opportunity", new Guid(getRecordid), cols);
				DateTime _arrivaldatedt = evt.New_arrivaldate ?? DateTime.MinValue;
				DateTime _departuredatedt = evt.New_departuredate ?? DateTime.MinValue;

				logger.Info("1260 Dynamicgridview Page:  Update Roomblock Status Method: Started");

				// Define the entity attributes (database table columns) that are to be retrieved.

				New_roompattern entity = new New_roompattern();

				EntityCollection entityCollection = CheckRoomPatternecords(_eventID, _service);
				logger.Info("1270 Dynamicgridview Page:  Update Roomblock Status Method: After service execution");
				Hashtable hshTableRoomPattern = new Hashtable();

				if (entityCollection.Entities.Count == 0)
					return;

				logger.Info("1280 Dynamicgridview Page: entityCollection.BusinessEntities.Length:: " + entityCollection.Entities.Count);

				for (int j = 0; j < entityCollection.Entities.Count; j++)
				{
					entity = (New_roompattern)entityCollection.Entities[j];
					// logger.Info("Dynamicgridview Page:  Retrieve Roomblock  Method: Retrieve Rooom Pattern Entity Value " + entity);


					//Added by ZSL Team on 28-06-2012
					if (entity.Bcmc_Date != null)
						hshTableRoomPattern.Add("bcmc_date" + j, entity.Bcmc_Date);
					else
						hshTableRoomPattern.Add("bcmc_date" + j, "01/01/0001");
				}

				if (hshTableRoomPattern.Count > 0)
				{
					string tempArrivalDateRoomPattern = hshTableRoomPattern["bcmc_date0"].ToString();


					if (tempArrivalDateRoomPattern != "01/01/0001")
					{
						logger.Info("1290 Dynamicgridview Page:  Update Roomblock Status Method: Retrieve Rooom Pattern ArrivalDate " + hshTableRoomPattern["bcmc_date0"].ToString());
						string tempDepartureDateRoomPattern = hshTableRoomPattern["bcmc_date" + (hshTableRoomPattern.Count - 1).ToString()].ToString();
						logger.Info("1300 Dynamicgridview Page:  Update Roomblock Status  Method: Retrieve Rooom Pattern ArrivalDate " + hshTableRoomPattern["bcmc_date" + (hshTableRoomPattern.Count - 1).ToString()].ToString());



						DateTime dtdeparture = _departuredatedt;

						dtdeparture = dtdeparture.AddDays(-1);
						string _Departuredate = Convert.ToString(dtdeparture.ToShortDateString());

						DateTime dtTempArrTime = Convert.ToDateTime(tempArrivalDateRoomPattern);
						DateTime dtArrivalDate = _arrivaldatedt;


						DateTime dtTempDepTime = Convert.ToDateTime(tempDepartureDateRoomPattern);
						DateTime dtDeparturedate = Convert.ToDateTime(_Departuredate);

						logger.Info("1310 Arrival Date Check dtArrivalDate: + " + dtArrivalDate.ToString());
						logger.Info("1320 Arrival Date Check dtTempArrTime: + " + dtTempArrTime.ToString());


						//logger.Info("Dynamicgridview Page:   UpdateRoomblockStatus Method: Started");

						if (gvFormLoad.Rows.Count > 0)
						{
							for (int i = 0; i < gvFormLoad.Rows.Count; i++)
							{
								// Create the RoomPattern object.
								New_roompattern roompattern = new New_roompattern();

								// Set the RoomPattern object properties to be updated.
								HiddenField txtcurrentpercent = (HiddenField)gvFormLoad.Rows[i].FindControl("hdnfdValue");

								string CPeak = txtcurrentpercent.Value;

								int intCPeak = 0;
								if ((((HiddenField)(gvFormLoad.Rows[i].FindControl("hdnfdValue"))).Value != string.Empty) && ((HiddenField)(gvFormLoad.Rows[i].FindControl("hdnfdValue"))) != null)
								{
									if (CPeak.Contains("."))
									{
										intCPeak = Convert.ToInt32(CPeak.Split('.')[0].ToString());
									}
									else
									{
										intCPeak = Convert.ToInt32(CPeak);
									}
								}
								roompattern.New_PercentofPeak = intCPeak;
								//logger.Info("############################### UpdateRoomBlockStatus Method: % Of Peak   ##########################################");
								logger.Info("1330 roompattern.new_percentofpeak = " + roompattern.New_PercentofPeak);
								//logger.Info("############################### UpdateRoomBlockStatus Method: % Of Peak   ########################################");

								// The RoomPatternid.Value is the GUID of the record to be changed.

								roompattern.New_roompatternId = new Guid(dtretrieve.Rows[i]["RoomGUID"].ToString());

								string CRoom = "0";

								int intCRoom = 0;
								if (gvFormLoad.Rows[i].Enabled == true)
								{
									TextBox txtcurrentroom = (TextBox)gvFormLoad.Rows[i].FindControl("txtCBlock");

									CRoom = txtcurrentroom.Text;


									if ((((TextBox)(gvFormLoad.Rows[i].FindControl("txtCBlock"))).Text != string.Empty) && ((TextBox)(gvFormLoad.Rows[i].FindControl("txtCBlock"))).Text != null)
									{
										if (CRoom.Contains("."))
										{
											intCRoom = Convert.ToInt32(CRoom.Split('.')[0].ToString());
                        }
										else
										{
											intCRoom = Convert.ToInt32(CRoom);
										}
									}
									else
									roompattern.New_RoomBlock = intCRoom;

									//logger.Info("####################   UpdateRoomBlockStatus Method: Current RoomBlock ######################");
									logger.Info("1340 roompattern.new_roomblock  " + roompattern.New_RoomBlock);
									//logger.Info("#################### UpdateRoomBlockStatus Method: Current RoomBlock   #######################");


									// The RoomPatternid is a key that references the ID of the RoomPattern to be updated.

									// Update the RoomPattern.

									//logger.Info("-------------------------------------  UpdateRoomBlockStatus Method   ----------------------------------------------");
									logger.Info("1350 roompattern.new_percentofpeak = " + roompattern.New_PercentofPeak + "- roompattern.new_roomblock " + roompattern.New_RoomBlock);
									//logger.Info("------------------------------------   UpdateRoomBlockStatus Method  ------------------------------------------------");

								}
								else
								{
									//For Diasbled Records Current RoomBlock value set to zero  .
									//ADD By ZSL TEAM  ON 16/Aug/2012
									intCRoom = 0;
									roompattern.New_RoomBlock = intCRoom;
									//logger.Info("####################   UpdateRoomBlockStatus Method: Disabled  Current RoomBlock ######################");
									logger.Info("1360 roompattern.new_roomblock  " + roompattern.New_RoomBlock);
									//logger.Info("#################### UpdateRoomBlockStatus Method: Disabled  Current RoomBlock   #######################");

								}

								int intdaynumber = i + 1;
								roompattern.New_DayNumber = intdaynumber;
								logger.Info("1370 Dynamicgridview Page:  UpdateRoomblockStatus Method: Before Update");
								_service.Update(roompattern);
								logger.Info("1380 Dynamicgridview Page:  UpdateRoomblockStatus Method: Updated Successfully");

							}
							// Update an attribute retrieved via RetrieveAttributeRequest

							logger.Info("1390 Dynamicgridview Page:   BindPeakroom Method: Started");

							String jsCode = BindPeakroom(gvFormLoad, _eventID);
							if (Updatestatus == 1)
                        {
								string myscript = jsCode + "alert('Successfully updated ');";
								Page.ClientScript.RegisterStartupScript(this.GetType(), "myscript", myscript, true);
							}

							logger.Info("1400 Dynamicgridview Page:   BindPeakroom Method: Ended");
							RetrieveBasedonStatus(_service);
							btnlead.Enabled = true;
                        }
						else if (gvRoomBlock.Rows.Count > 0)
						{
							for (int i = 0; i < gvRoomBlock.Rows.Count; i++)
							{
								// Create the RoomPattern object.
								New_roompattern roompattern = new New_roompattern();
								// Set the RoomPattern object properties to be updated.
								HiddenField txtcurrentpercent = (HiddenField)gvRoomBlock.Rows[i].FindControl("hdnfdValue");
								string CPeak = txtcurrentpercent.Value;

								int intCPeak = 0;
								if ((((HiddenField)(gvRoomBlock.Rows[i].FindControl("hdnfdValue"))).Value != string.Empty) && ((HiddenField)(gvRoomBlock.Rows[i].FindControl("hdnfdValue"))) != null)
								{
									if (CPeak.Contains("."))
									{
										intCPeak = Convert.ToInt32(CPeak.Split('.')[0].ToString());
									}
									else
									{
										intCPeak = Convert.ToInt32(CPeak);
									}
								}
								roompattern.New_PercentofPeak = intCPeak;
								//logger.Info("############################ UpdateRoomBlockStatus Method: Current % Of Peak  ########################");
								logger.Info("1410  roompattern.new_percentofpeak = " + roompattern.New_PercentofPeak);
								//logger.Info("##########################   UpdateRoomBlockStatus Method: Current % Of Peak   #######################");


								TextBox txtcurrentroom = (TextBox)gvRoomBlock.Rows[i].FindControl("txtCBlock");
								string CRoom = txtcurrentroom.Text;


								int intCRoom = 0;

								if ((((TextBox)(gvRoomBlock.Rows[i].FindControl("txtCBlock"))).Text != string.Empty) && ((TextBox)(gvRoomBlock.Rows[i].FindControl("txtCBlock"))).Text != null)
								{
									if (CRoom.Contains("."))
									{
										intCRoom = Convert.ToInt32(CRoom.Split('.')[0].ToString());
									}
									else
									{
										intCRoom = Convert.ToInt32(CRoom);
			                        }
								}
								roompattern.New_RoomBlock = intCRoom;
								//logger.Info("############################ UpdateRoomBlockStatus Method: Current RoomBlock   ###################################");
								logger.Info("1420 roompattern.new_roomblock  " + roompattern.New_RoomBlock);
								//logger.Info("##########################  UpdateRoomBlockStatus Method: Current RoomBlock    #################################");
								// The roompatternid is a key that references the ID of the RommPattern to be updated.
								// The roompatternid.Value is the GUID of the record to be changed.                     

								logger.Info("UpdateRoomblockStatus   Method event Id:" + _eventID);
								roompattern.New_roompatternId = new Guid(_eventID);

								// Update the RommPattern.                     
								//logger.Info("----------------------------------  UpdateRoomblockStatus Method     ------------------------------");
								logger.Info("1430 roompattern.new_percentofpeak = " + roompattern.New_PercentofPeak + "- roompattern.new_roomblock " + roompattern.New_RoomBlock);
								//logger.Info("----------------------------------   UpdateRoomblockStatus Method  --------------------------------");

								logger.Info("1440 Dynamicgridview Page:  UpdateRoomblockStatus Method: Before Update");
								_service.Update(roompattern);
								logger.Info("1450 Dynamicgridview Page:  UpdateRoomblockStatus Method: Updated Successfully");
							}

							String jsCode = BindPeakroom(gvRoomBlock, _eventID);

							string myscript = jsCode + "alert('Successfully updated ');";
							Page.ClientScript.RegisterStartupScript(this.GetType(), "myscript", myscript, true);

							RetrieveBasedonStatus(_service);
							btnlead.Enabled = true;
						}

						logger.Info("1460 Dynamicgridview Page:  UpdateRoomblockStatus Method: End");
					}
					else
					{
						DisplayNullDateRecords(entityCollection);
					}
				}
			}
			catch (System.Web.Services.Protocols.SoapException ex)
			{
				logger.Error(ex.Detail.InnerText, ex);
			}
			catch (Exception ex)
			{
				logger.Error("Dynamicgridview Page:  UpdateRoomblockStatus Method: Error" + ex.ToString());
			}
		}

		#endregion


#region Original UpdateStatus
		private void UpdateRoomblockStatus(string _eventID, int Updatestatus)
		{
			try
			{
				logger.Info("1470 Dynamicgridview Page:   UpdateRoomblockStatus Method: Started");

				if (gvFormLoad.Rows.Count > 0)
				{
					for (int i = 0; i < gvFormLoad.Rows.Count; i++)
					{
						// Create the RoomPattern object.
						New_roompattern roompattern = new New_roompattern();

						// Set the RoomPattern object properties to be updated.

						HiddenField txtcurrentpercent = (HiddenField)gvFormLoad.Rows[i].FindControl("hdnfdValue");

						string CPeak = txtcurrentpercent.Value;

						int intCPeak = 0;

						if ((((HiddenField)(gvFormLoad.Rows[i].FindControl("hdnfdValue"))).Value != string.Empty) && ((HiddenField)(gvFormLoad.Rows[i].FindControl("hdnfdValue"))) != null)
						{

							if (CPeak.Contains("."))
							{
								intCPeak = Convert.ToInt32(CPeak.Split('.')[0].ToString());
							}
							else
							{
								intCPeak = Convert.ToInt32(CPeak);
							}
						}
						roompattern.New_PercentofPeak = intCPeak;
						//logger.Info("############################### UpdateRoomBlockStatus Method: % Of Peak   ##########################################");
						logger.Info("1480 roompattern.new_percentofpeak = " + roompattern.New_PercentofPeak);
						//logger.Info("############################### UpdateRoomBlockStatus Method: % Of Peak   ########################################");


						// The RoomPatternid.Value is the GUID of the record to be changed.
						roompattern.New_roompatternId = new Guid(dtretrieve.Rows[i]["RoomGUID"].ToString());

						string CRoom = "0";

						int intCRoom = 0;
						if (gvFormLoad.Rows[i].Enabled == true)
						{
							TextBox txtcurrentroom = (TextBox)gvFormLoad.Rows[i].FindControl("txtCBlock");

							CRoom = txtcurrentroom.Text;


							if ((((TextBox)(gvFormLoad.Rows[i].FindControl("txtCBlock"))).Text != string.Empty) && ((TextBox)(gvFormLoad.Rows[i].FindControl("txtCBlock"))).Text != null)
							{
								if (CRoom.Contains("."))
								{
									intCRoom = Convert.ToInt32(CRoom.Split('.')[0].ToString());
								}
								else
								{
									intCRoom = Convert.ToInt32(CRoom);
								}
							}
							roompattern.New_RoomBlock = intCRoom;

							//logger.Info("####################   UpdateRoomBlockStatus Method: Current RoomBlock ######################");
							logger.Info("1490 roompattern.new_roomblock  " + roompattern.New_RoomBlock);
							//logger.Info("#################### UpdateRoomBlockStatus Method: Current RoomBlock   #######################");


							// The RoomPatternid is a key that references the ID of the RoomPattern to be updated.

							// Update the RoomPattern.

							//logger.Info("-------------------------------------  UpdateRoomBlockStatus Method   ----------------------------------------------");
							//logger.Info("roompattern.new_percentofpeak = " + roompattern.new_percentofpeak.Value + "- roompattern.new_roomblock " + roompattern.new_roomblock.Value);
							//logger.Info("------------------------------------   UpdateRoomBlockStatus Method  ------------------------------------------------");

						}
						else
						{
							//For Diasbled Records Current RoomBlock value set to zero  .
							//ADD By ZSL TEAM  ON 16/Aug/2012
							intCRoom = 0;
							roompattern.New_RoomBlock = intCRoom;
							//logger.Info("####################   UpdateRoomBlockStatus Method: Disabled  Current RoomBlock ######################");
							logger.Info("1500 roompattern.new_roomblock  " + roompattern.New_RoomBlock);
							//logger.Info("#################### UpdateRoomBlockStatus Method: Disabled  Current RoomBlock   #######################");

						}

						int intdaynumber = i + 1;
						roompattern.New_DayNumber = intdaynumber;
						logger.Info("1510 Dynamicgridview Page:  UpdateRoomblockStatus Method: Before Update");
						_service.Update(roompattern);
						logger.Info("1520 Dynamicgridview Page:  UpdateRoomblockStatus Method: Updated Successfully");

					}
					// Update an attribute retrieved via RetrieveAttributeRequest

					logger.Info("1530 Dynamicgridview Page:   BindPeakroom Method: Started");

					String jsCode = BindPeakroom(gvFormLoad, _eventID);

					if (Updatestatus == 1)
					{
						string myscript = jsCode + "alert('Successfully updated ');";
						Page.ClientScript.RegisterStartupScript(this.GetType(), "myscript", myscript, true);
					}

					logger.Info("1540 Dynamicgridview Page:   BindPeakroom Method: Ended");
					RetrieveBasedonStatus(_service);
					btnlead.Enabled = true;

				}


				else if (gvRoomBlock.Rows.Count > 0)
				{
					for (int i = 0; i < gvRoomBlock.Rows.Count; i++)
					{
						// Create the RoomPattern object.
						New_roompattern roompattern = new New_roompattern();
						// Set the RoomPattern object properties to be updated.
						HiddenField txtcurrentpercent = (HiddenField)gvRoomBlock.Rows[i].FindControl("hdnfdValue");
						string CPeak = txtcurrentpercent.Value;

						int intCPeak = 0;
						if ((((HiddenField)(gvRoomBlock.Rows[i].FindControl("hdnfdValue"))).Value != string.Empty) && ((HiddenField)(gvRoomBlock.Rows[i].FindControl("hdnfdValue"))) != null)
						{
							if (CPeak.Contains("."))
							{
								intCPeak = Convert.ToInt32(CPeak.Split('.')[0].ToString());
							}
							else
							{
								intCPeak = Convert.ToInt32(CPeak);
							}
						}
						roompattern.New_PercentofPeak = intCPeak;
						//logger.Info("############################ UpdateRoomBlockStatus Method: Current % Of Peak  ########################");
						logger.Info("1550  roompattern.new_percentofpeak = " + roompattern.New_PercentofPeak);
						//logger.Info("##########################   UpdateRoomBlockStatus Method: Current % Of Peak   #######################");


						TextBox txtcurrentroom = (TextBox)gvRoomBlock.Rows[i].FindControl("txtCBlock");
						string CRoom = txtcurrentroom.Text;


						int intCRoom = 0;

						if ((((TextBox)(gvRoomBlock.Rows[i].FindControl("txtCBlock"))).Text != string.Empty) && ((TextBox)(gvRoomBlock.Rows[i].FindControl("txtCBlock"))).Text != null)
						{
							if (CRoom.Contains("."))
							{
								intCRoom = Convert.ToInt32(CRoom.Split('.')[0].ToString());
							}
							else
							{
								intCRoom = Convert.ToInt32(CRoom);
							}
						}
						roompattern.New_RoomBlock = intCRoom;
						//logger.Info("############################ UpdateRoomBlockStatus Method: Current RoomBlock   ###################################");
						logger.Info("1560 roompattern.new_roomblock  " + roompattern.New_RoomBlock);
						//logger.Info("##########################  UpdateRoomBlockStatus Method: Current RoomBlock    #################################");
						// The roompatternid is a key that references the ID of the RommPattern to be updated.
						// The roompatternid.Value is the GUID of the record to be changed.                    

						logger.Info("UpdateRoomblockStatus   Method event Id:" + _eventID);
						roompattern.New_roompatternId = new Guid(_eventID);

						// Update the RommPattern.                     
						//logger.Info("----------------------------------  UpdateRoomblockStatus Method     ------------------------------");
						logger.Info("1570 roompattern.new_percentofpeak = " + roompattern.New_PercentofPeak + "- roompattern.new_roomblock " + roompattern.New_RoomBlock);
						//logger.Info("----------------------------------   UpdateRoomblockStatus Method  --------------------------------");

						//logger.Info("Dynamicgridview Page:  UpdateRoomblockStatus Method: Before Update");
						_service.Update(roompattern);
						logger.Info("1580 Dynamicgridview Page:  UpdateRoomblockStatus Method: Updated Successfully");
                    }


					String jsCode = BindPeakroom(gvRoomBlock, _eventID);

					string myscript = jsCode + "alert('Successfully updated ');";
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "myscript", myscript, true);

                    RetrieveBasedonStatus(_service);
                    btnlead.Enabled = true;
                }

				logger.Info("1590 Dynamicgridview Page:  UpdateRoomblockStatus Method: End");
            }
			catch (System.Web.Services.Protocols.SoapException ex)
			{
				logger.Error(ex.Detail.InnerText, ex);
			}
            catch (Exception ex)
            {
                logger.Error("Dynamicgridview Page:  UpdateRoomblockStatus Method: Error" + ex.ToString());
            }
        }
		#endregion



		private String BindPeakroom(GridView gvRoomBlock, string _eventID)
        {
            try
            {
				logger.Info("1600 Dynamicgridview Page:   gvRoomBlock.Rows.Count " + gvRoomBlock.Rows.Count);
				//logger.Info("Dynamicgridview Page:   BindPeakroom Method: Started");

				_peakRoomNight = 0;
				_totalRoomBlock = 0;
                for (int i = 0; i < gvRoomBlock.Rows.Count; i++)
                {
                    TextBox txtTotalroomblock = new TextBox();

                    if ((((TextBox)(gvRoomBlock.Rows[i].FindControl("txtCBlock"))).Text != string.Empty) && ((TextBox)(gvRoomBlock.Rows[i].FindControl("txtCBlock"))).Text != null)
                    {
                        txtTotalroomblock = (TextBox)gvRoomBlock.Rows[i].FindControl("txtCBlock");
                    }
                    else
                        txtTotalroomblock.Text = "0";

					int rooms = int.Parse(txtTotalroomblock.Text);
					_totalRoomBlock += rooms;

					if (rooms > _peakRoomNight)
						_peakRoomNight = rooms;
                }

				logger.InfoFormat("Dynamicgridview Page:   Total HotelRooms {0}", _totalRoomBlock);
				logger.InfoFormat("Dynamicgridview Page:   Total PeakRoom Nights {0}", _peakRoomNight);
				logger.Info("1610 Dynamicgridview Page:   BindPeakroom Method: End. NS10: " + _eventID);

				Opportunity Opportunity_ = new Opportunity();
				//NS 5/27/13. Opportunity.opportunityid = new RoomBlock.CrmService.Key() {Value = new Guid(_eventID)};
				Opportunity_.OpportunityId = new Guid(_eventID);

				Opportunity_.New_HotelRoomNights = _totalRoomBlock;
				Opportunity_.New_PeakHotelRoomNights = _peakRoomNight;

				logger.Info("1620 Dynamicgridview Page:  BindPeakroom Method: Before Update The Total Rooms and PeakRoomNights");
				_service.Update(Opportunity_);
				logger.Info("1630 Dynamicgridview Page:  BindPeakroom Method: Updated Successfully ");

                }
			catch (System.Web.Services.Protocols.SoapException ex)
			{
				logger.Error(ex.Detail.InnerText, ex);
            }
            catch (Exception ex)
            {

                logger.Error("Dynamicgridview Page: BindPeakroom Method: Error" + ex.ToString());
            }

			// Build the JavaScript code to be used to update the CRM event form.
			return String.Format("updateParent({0}, {1}); ", _totalRoomBlock, _peakRoomNight);
        }

        private void CheckEventUpdateStatus(OrganizationService _service, string getRecordid)
        {
            EntityCollection _businessEntitiesRP = AssignDayNumberRoomPattern(getRecordid, _service);
            New_roompattern entity = new New_roompattern();
            for (int i = 0; i < _businessEntitiesRP.Entities.Count; i++)
            {
                Entity rpEntity = _businessEntitiesRP.Entities[i];

                entity = (New_roompattern)rpEntity;
                entity.Bcmc_statustype = 0;
				logger.Info("1640 Dynamicgridview Page:  CheckEventUpdateStatus: Before Update status");
                _service.Update(entity);
				logger.Info("1650 Dynamicgridview Page:  CheckEventUpdateStatus: After Update Successfully");
            }
        }

        private EntityCollection AssignDayNumberRoomPattern(string eventGUID, OrganizationService _service)
        {
            ConditionExpression conditionRP = new ConditionExpression();
            conditionRP.AttributeName = "new_eventid";
            conditionRP.Operator = ConditionOperator.Equal;
            conditionRP.Values.Add(eventGUID.ToString());

            FilterExpression filterRP = new FilterExpression();
            filterRP.FilterOperator = LogicalOperator.And;
            filterRP.Conditions.Add(conditionRP);

            OrderExpression orderExpr = new OrderExpression();
            orderExpr.AttributeName = "bcmc_date";
            orderExpr.OrderType = OrderType.Ascending;

            QueryExpression queryRP = new QueryExpression();
            queryRP.EntityName = "new_roompattern";
            queryRP.ColumnSet = new ColumnSet(true);
            queryRP.Criteria = filterRP;
            queryRP.Orders.Add(orderExpr);

			logger.Info("1660 Dynamicgridview Page:  AssignDayNumberRoomPattern  Method: Before service execution");
            EntityCollection _businessEntitiesRP = _service.RetrieveMultiple(queryRP);
			logger.Info("1670 Dynamicgridview Page:  AssignDayNumberRoomPattern  Method: After service execution");

            return _businessEntitiesRP;
        }

		/// <summary>
		/// Display an alert box when the page completes posting back.
		/// </summary>
		/// <param name="message"></param>
		protected void Alert(String message)
		{
			logger.InfoFormat("Enter Alert({0})", message);
			string myscript = String.Format("alert('{0}');", message);
			Page.ClientScript.RegisterStartupScript(this.GetType(), "myscript", myscript, true);
		}
		#endregion
#endif
	}
}
#endif